#include <matrix/math.hpp>
#include <matrix/integration.hpp>
#include <Fixed_wing_aircraft_model/FixedwingSpec.h> 
#include <Fixed_wing_aircraft_model/FixedwingDynamics.h>
#include <propagation/StatePropagation.h>
#include <Fixed_wing_aircraft_model/CurrentState.h>
#include <controller/GainParameter.h>
#include <controller/NdiParameter.h>
#include <controller/MainController.h>
#include <cstdio>
#include <iostream> 
#include <make_csv/FixedWingLog.h>
#include <vector>
#include <fstream>


int main() {
    /*각도 출력을 위한 로직*/
    constexpr double kPi = 3.14159265358979323846;
    auto rad2deg = [kPi](double r) { return r * 180.0 / kPi; };

    
    /* 고정익 모델 생성 및 컨트롤러 객체 생성*/
    FixedwingDynamics vehicle_0( g_FixedwingSpec);
    MainController vehicle_0_controller(g_FixedwingSpec, g_GainParameter, g_NdiParameter);
    
    /*초기상태 입력을 위한 객체 생성*/
    CurrentState vehicle_0_state;
        vehicle_0_state.set_speed(g_FixedwingSpec.min_speed+10);   
        vehicle_0_state.set_at(g_FixedwingSpec.at_min/2);

    /*Setpoint 생성 */
    CurrentState state_setpoint;
        state_setpoint.set_speed( (g_FixedwingSpec.min_speed+g_FixedwingSpec.max_speed )/2);
        state_setpoint.set_north_position(1000);
        state_setpoint.set_east_position(200.0);
        state_setpoint.set_down(-5000.0);
        matrix::Vector<double, 11> target_setpoint = state_setpoint.get_total_state();



    /*시물레이션 시간 설정 및 이산 시간 설정*/
    double t = 0.0;      // 현재 시간
    double const dt = 0.01;    // 시간 간격 (0.01초)

    /* 적분기 생성 */
    ProPagation propagator; 

    /* csv 데이터 저장을 위한 객체 생성 */
    FixedWingLog vehicle_0_history(0);

    





/* test 문장 */
    while(t<10 )
    {
    // 3. 결과 업데이트
    matrix::Vector<double, 11> vehicle_0_current_state = vehicle_0_state.get_total_state();

  

    matrix::Vector<double, 4> vehicle_0_control_input = vehicle_0_controller.calculate_control_input(
            vehicle_0_current_state ,
            target_setpoint
        );

    matrix::Vector<double, 11> vehicle_0_next_state = propagator.step(vehicle_0, vehicle_0_current_state, vehicle_0_control_input, t, dt);
    vehicle_0_state.set_total_state(vehicle_0_next_state);

    FixedWingData_t vehicle_0_data;
        vehicle_0_data.time = t;
        vehicle_0_data.north = vehicle_0_next_state(0);
        vehicle_0_data.east = vehicle_0_next_state(1);
        vehicle_0_data.down = vehicle_0_next_state(2);
        vehicle_0_data.roll = rad2deg(vehicle_0_next_state(3));
        vehicle_0_data.pitch = rad2deg(vehicle_0_next_state(4));
        vehicle_0_data.yaw = rad2deg(vehicle_0_next_state(5));
        vehicle_0_data.speed = vehicle_0_next_state(6);
        vehicle_0_data.p = rad2deg(vehicle_0_next_state(7));
        vehicle_0_data.q = rad2deg(vehicle_0_next_state(8));
        vehicle_0_data.r = rad2deg(vehicle_0_next_state(9));
        vehicle_0_data.at = vehicle_0_next_state(10);
        
        vehicle_0_history.addData(vehicle_0_data);


    t += dt;    // 시간 업데이트

    // std::cout << "t=" << t
    //       << " north=" << vehicle_0_next_state(0)
    //       << " easr="  << vehicle_0_next_state(1)
    //       << " down="  << vehicle_0_next_state(2)
    //       << " roll="  << rad2deg(vehicle_0_next_state(3))
    //       << " pitch=" << rad2deg(vehicle_0_next_state(4))
    //       << " speed=" << vehicle_0_next_state(6)
    //       << std::endl;


    }

    /*CSV 파일로 만들 값 저장*/

    vehicle_0_history.saveToCSV("../../make_csv/agent_0.csv");
    std::cout << "CSV file saved successfully!" << std::endl;

    /* 나중에 plot 최대 최소 허용 state을 반영하기 위한 코드임  */
     std::ofstream config("../../make_csv/aircraft_spec.json");
    config << "{\n"
        << "  \"max_speed\": " << g_FixedwingSpec.max_speed << ",\n"
        << "  \"min_speed\": " << g_FixedwingSpec.min_speed << ",\n"
        << "  \"max_roll\": " << g_FixedwingSpec.max_roll * 180.0 / M_PI << ",\n"
        << "  \"min_roll\": " << g_FixedwingSpec.min_roll * 180.0 / M_PI << ",\n"
        << "  \"max_pitch\": " << g_FixedwingSpec.max_pitch * 180.0 / M_PI << ",\n"
        << "  \"min_pitch\": " << g_FixedwingSpec.min_pitch * 180.0 / M_PI << ",\n"  // 쉼표 추가
        << "  \"max_p\": " << g_FixedwingSpec.p_max * 180.0 / M_PI << ",\n"  // 각도 변환 제거
        << "  \"min_p\": " << g_FixedwingSpec.p_min * 180.0 / M_PI<< ",\n"
        << "  \"max_q\": " << g_FixedwingSpec.q_max * 180.0 / M_PI<< ",\n"
        << "  \"min_q\": " << g_FixedwingSpec.q_min * 180.0 / M_PI<< ",\n"
        << "  \"max_r\": " << g_FixedwingSpec.r_max * 180.0 / M_PI<< ",\n"
        << "  \"min_r\": " << g_FixedwingSpec.r_min * 180.0 / M_PI<< ",\n"
        << "  \"max_at\": " << g_FixedwingSpec.at_max << ",\n"  // 각도 변환 제거
        << "  \"min_at\": " << g_FixedwingSpec.at_min << "\n"   // 마지막은 쉼표 없음
        << "}\n";
    config.close();


}