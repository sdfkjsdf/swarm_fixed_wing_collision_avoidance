#ifndef FIXEDWINGLOG_H
#define FIXEDWINGLOG_H

#include <vector>
#include <string>
#include <fstream>


struct FixedWingData_t {
    double time;
    double north;
    double east;
    double down;
    double roll;
    double pitch;
    double yaw;
    double speed;
    double p;
    double q;
    double r;
    double at;

};

class FixedWingLog{

    public:
        FixedWingLog(int id) : m_agent_id(id){}

        void addData(const FixedWingData_t& d) { m_data_history.push_back(d);}

        void saveToCSV(const std::string& filename) {
        std::ofstream csv(filename);
        
        // 첫 행: time
        csv << "state";
        for(const auto& d : m_data_history) {
            csv << "," << d.time;
        }
        csv << "\n";
        
        // 각 상태별 행
        auto write_row = [&](const std::string& name, auto getter) {
            csv << name;
            for(const auto& d : m_data_history) {
                csv << "," << getter(d);
            }
            csv << "\n";
        };
        
        write_row("north", [](const auto& d) { return d.north; });
        write_row("east",  [](const auto& d) { return d.east; });
        write_row("down",  [](const auto& d) { return d.down; });
        write_row("roll",  [](const auto& d) { return d.roll; });
        write_row("pitch", [](const auto& d) { return d.pitch; });
        write_row("yaw",   [](const auto& d) { return d.yaw; });
        write_row("speed", [](const auto& d) { return d.speed; });
        write_row("p",     [](const auto& d) { return d.p; });
        write_row("q",     [](const auto& d) { return d.q; });
        write_row("r",     [](const auto& d) { return d.r; });
        write_row("at",    [](const auto& d) { return d.at; });
        
        csv.close();
    }
    
    int getAgentId() const { return m_agent_id; }






    private:
        int m_agent_id;
        std::vector<FixedWingData_t> m_data_history;






};

#endif //  FIXEDWINGDATA_H