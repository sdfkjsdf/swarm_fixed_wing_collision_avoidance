#include <matrix/math.hpp>
#include "FlockingGuidance.h"
#include <formation_guidance/FlockingParameter.h>
#include <fixed_wing_aircraft_model/FixedwingSpec.h>
#include <ts_message/TsMessage.h>
#include <ts_message/StateInformation.h>
#include<cmath>

FlockingGuidance::FlockingGuidance(const FixedwingSpec_t& spec ,const Flockingparameter_t& flocking_gain)
            :m_spec(spec),
            m_flocking_gain(flocking_gain) {}

 matrix::Vector<double,3> FlockingGuidance::caclulate_roll_yawrate_ground_acc(const matrix::Vector<double,11>& state,
                                                                    const TsMessage_t other_information1,
                                                                    const TsMessage_t other_information2,
                                                                    const TsMessage_t other_information3,
                                                                    const TsMessage_t other_information4)
{
/*자신의 정보를 받아오기 */
matrix::Vector<double,4> self_state{};

    const double n = state(0);
    const double e = state(1);
    const double roll = state(3);
    const double pitch = state(4);
    const double yaw = state(5);
    const double speed = state(6);
    const double q = state(8);
    const double r = state(9);
    const double c_r = std::cos(roll);
    const double s_r = std::sin(roll);
    const double c_p = std::cos(pitch);
    const double s_p = std::sin(pitch);
    const double c_y = std::cos(yaw);
    const double s_y = std::sin(yaw);


    self_state(0)=n;
    self_state(1)=e;
    self_state(2)=speed * c_p* c_y ;
    self_state(3)=speed * c_p * s_y;



/*flocking 파라미터를 설정*/
   const double lammda=m_flocking_gain.m_lammda;
   const double k_1=m_flocking_gain.m_k1;
   const double k_2=m_flocking_gain.m_k2;
   const double desired_distance=m_flocking_gain.m_desired_distance;


/* 자신의 좌표계로 변환*/
matrix::Vector<double,2> nose_direction{};
matrix::Vector<double,2> wing_direction{};
    nose_direction(0)=c_y;
    nose_direction(1)=s_y;
    wing_direction(0)=-s_y;
    wing_direction(1)=c_y;


/*통신 받은 정보에서 필요한 정보를 추출*/
matrix::Vector<double, 4> other_state1 = StateInformation::get_state_other_state(other_information1).slice<4,1>(0,0); 
matrix::Vector<double, 4> other_state2 = StateInformation::get_state_other_state(other_information2).slice<4,1>(0,0);
matrix::Vector<double, 4> other_state3 = StateInformation::get_state_other_state(other_information3).slice<4,1>(0,0);
matrix::Vector<double, 4> other_state4 = StateInformation::get_state_other_state(other_information4).slice<4,1>(0,0);



/* 상대 벡터 연산 */
matrix::Matrix<double,4,4> relative_state{}; 

relative_state.slice<4, 1>(0, 0) = other_state1 - self_state;
relative_state.slice<4, 1>(0, 1) = other_state2 - self_state;
relative_state.slice<4, 1>(0, 2) = other_state3 - self_state;
relative_state.slice<4, 1>(0, 3) = other_state4 - self_state;







}

   








                                                                    





