#include <matrix/math.hpp>
#include <matrix/integration.hpp>
#include <Fixed_wing_aircraft_model/FixedwingSpec.h> 
#include <Fixed_wing_aircraft_model/FixedwingDynamics.h>
#include <propagation/StatePropagation.h>
#include <Fixed_wing_aircraft_model/CurrentState.h>
#include <controller/GainParameter.h>
#include <controller/NdiParameter.h>
#include <controller/MainController.h>
#include <cstdio>
#include <iostream> 
#include <make_csv/FixedWingLog.h>
#include <vector>
#include <fstream>
#include<ts_message/TsMessage.h>
#include<random>


int main() {
    /*각도 출력을 위한 로직*/
    constexpr double kPi = 3.14159265358979323846;
    auto rad2deg = [kPi](double r) { return r * 180.0 / kPi; };

    const int total_vehicle_num=5;

    
    /* 고정익 모델 생성 */
    FixedwingDynamics vehicle_0( g_FixedwingSpec);
    FixedwingDynamics vehicle_1( g_FixedwingSpec);
    FixedwingDynamics vehicle_2( g_FixedwingSpec);
    FixedwingDynamics vehicle_3( g_FixedwingSpec);
    FixedwingDynamics vehicle_4( g_FixedwingSpec);




    /* 컨트롤러 선언*/
    MainController vehicle_0_controller(g_FixedwingSpec, g_GainParameter, g_NdiParameter);
    MainController vehicle_1_controller(g_FixedwingSpec, g_GainParameter, g_NdiParameter);
    MainController vehicle_2_controller(g_FixedwingSpec, g_GainParameter, g_NdiParameter);
    MainController vehicle_3_controller(g_FixedwingSpec, g_GainParameter, g_NdiParameter);
    MainController vehicle_4_controller(g_FixedwingSpec, g_GainParameter, g_NdiParameter);

    
    /*초기상태 입력을 위한 객체 생성*/
    CurrentState vehicle_0_state;
    CurrentState vehicle_1_state;
    CurrentState vehicle_2_state;
    CurrentState vehicle_3_state;
    CurrentState vehicle_4_state;


    /*무작위의 초기조건 생성 */

    
        std::random_device rd;
        std::mt19937 gen(rd());
        

        std::uniform_real_distribution<> north_dist(-1000, 1000);   // North 범위
        std::uniform_real_distribution<> east_dist(-1000, 1000);    // East 범위
        std::uniform_real_distribution<> down_dist(-10, +10);     // Down 범위 (음수 = 고도)
        std::uniform_real_distribution<> yaw_dist(-kPi, kPi);       // Yaw 범위
        std::uniform_real_distribution<> speed_dist(g_FixedwingSpec.min_speed + 5, 
                                                    g_FixedwingSpec.max_speed - 5);  // 속도
        std::uniform_real_distribution<> at_dist(g_FixedwingSpec.at_min, 
                                                g_FixedwingSpec.at_max);  // 가속도


        /* 초기상태 객체들을 배열로 */
        CurrentState initial_vehicle_states[total_vehicle_num];
        
        // 반복문으로 랜덤 초기값 설정
        for(int i = 0; i < total_vehicle_num; i++) {
            initial_vehicle_states[i].set_north_position(north_dist(gen));
            initial_vehicle_states[i].set_east_position(east_dist(gen));
            initial_vehicle_states[i].set_down(down_dist(gen));
            initial_vehicle_states[i].set_yaw(yaw_dist(gen));
            initial_vehicle_states[i].set_speed(speed_dist(gen));
            initial_vehicle_states[i].set_at(at_dist(gen));
            
            std::cout << "Vehicle " << i << " initialized at: "
                    << "N=" << initial_vehicle_states[i].get_total_state()(0) 
                    << " E=" << initial_vehicle_states[i].get_total_state()(1)
                    << " D=" << initial_vehicle_states[i].get_total_state()(2) 
                    << std::endl;
        }

       /*초기값 입력 */
      vehicle_0_state.set_total_state(initial_vehicle_states[0].get_total_state());
      vehicle_1_state.set_total_state(initial_vehicle_states[1].get_total_state());
      vehicle_2_state.set_total_state(initial_vehicle_states[2].get_total_state());
      vehicle_3_state.set_total_state(initial_vehicle_states[3].get_total_state());
      vehicle_4_state.set_total_state(initial_vehicle_states[4].get_total_state());

    

    /*Setpoint 생성 */
    CurrentState state_setpoint;
        state_setpoint.set_speed( (g_FixedwingSpec.min_speed+g_FixedwingSpec.max_speed )/2);
        state_setpoint.set_north_position(1000);
        state_setpoint.set_east_position(200.0);
        state_setpoint.set_down(-5000.0);
        matrix::Vector<double, 11> target_setpoint = state_setpoint.get_total_state();



    /*시물레이션 시간 설정 및 이산 시간 설정*/
    double t = 0.0;      // 현재 시간
    double const dt = 0.01;    // 시간 간격 (0.01초)

    /* 적분기 생성 */
    ProPagation propagator; 

    /*통신기 생성*/
    TsMessage_t ts_vehicle_0_msg;
    TsMessage_t ts_vehicle_1_msg;
    TsMessage_t ts_vehicle_2_msg;
    TsMessage_t ts_vehicle_3_msg;
    TsMessage_t ts_vehicle_4_msg;

    /* csv 데이터 저장을 위한 객체 생성 */
    FixedWingLog vehicle_0_history(0);
    FixedWingLog vehicle_1_history(1);
    FixedWingLog vehicle_2_history(2);
    FixedWingLog vehicle_3_history(3);
    FixedWingLog vehicle_4_history(4);

    





/* test 문장 */
    while(t<100)
    {
    /* 현재 상태를 받아오기 */
    /* 여기서 while 문 맨 처음에만 현재 상태를 받아오고 나머지는 계속해서 업데이트임 */
    matrix::Vector<double, 11> vehicle_0_current_state = vehicle_0_state.get_total_state();
    matrix::Vector<double, 11> vehicle_1_current_state = vehicle_1_state.get_total_state();
    matrix::Vector<double, 11> vehicle_2_current_state = vehicle_2_state.get_total_state();
    matrix::Vector<double, 11> vehicle_3_current_state = vehicle_3_state.get_total_state();
    matrix::Vector<double, 11> vehicle_4_current_state = vehicle_4_state.get_total_state();


    /* CSV로 만들 현재 상태를 지금 저장하기*/
    vehicle_0_history.addData(t, vehicle_0_current_state);
    vehicle_1_history.addData(t, vehicle_1_current_state);
    vehicle_2_history.addData(t, vehicle_2_current_state);
    vehicle_3_history.addData(t, vehicle_3_current_state);
    vehicle_4_history.addData(t, vehicle_4_current_state);



    /*foramation을 위한 통신 시작*/
    ts_vehicle_0_msg.broadcast_ts_message(0, t, false, false, vehicle_0_current_state);
    ts_vehicle_1_msg.broadcast_ts_message(0, t, false, false, vehicle_1_current_state);
    ts_vehicle_2_msg.broadcast_ts_message(0, t, false, false, vehicle_2_current_state);
    ts_vehicle_3_msg.broadcast_ts_message(0, t, false, false, vehicle_3_current_state);
    ts_vehicle_4_msg.broadcast_ts_message(0, t, false, false, vehicle_4_current_state);
    /*void broadcast_ts_message(int const sender_index,
                           double const time,
                           bool const leader_follower_switch,
                           bool const who_is_leader,
                           matrix::Vector<double,11> const& state)*/
    // vehicle_0_msg.print();
   

  
    /*제어입력 연산 */

    matrix::Vector<double, 4> vehicle_0_control_input = vehicle_0_controller.calculate_control_input(
            vehicle_0_current_state ,
            target_setpoint
        );
    matrix::Vector<double, 4> vehicle_1_control_input = vehicle_1_controller.calculate_control_input(
            vehicle_1_current_state ,
            target_setpoint
        );
    matrix::Vector<double, 4> vehicle_2_control_input = vehicle_2_controller.calculate_control_input(
            vehicle_2_current_state ,
            target_setpoint
        );
     matrix::Vector<double, 4> vehicle_3_control_input = vehicle_3_controller.calculate_control_input(
            vehicle_3_current_state ,
            target_setpoint
        );

     matrix::Vector<double, 4> vehicle_4_control_input = vehicle_4_controller.calculate_control_input(
            vehicle_4_current_state ,
            target_setpoint
        );






    /*적분시작*/
    matrix::Vector<double, 11> vehicle_0_next_state = propagator.step(vehicle_0, vehicle_0_current_state, vehicle_0_control_input, t, dt);
    matrix::Vector<double, 11> vehicle_1_next_state = propagator.step(vehicle_1, vehicle_1_current_state, vehicle_1_control_input, t, dt);
    matrix::Vector<double, 11> vehicle_2_next_state = propagator.step(vehicle_2, vehicle_2_current_state, vehicle_2_control_input, t, dt);
    matrix::Vector<double, 11> vehicle_3_next_state = propagator.step(vehicle_3, vehicle_3_current_state, vehicle_3_control_input, t, dt);
    matrix::Vector<double, 11> vehicle_4_next_state = propagator.step(vehicle_4, vehicle_4_current_state, vehicle_4_control_input, t, dt);

    
    /*실질적인 상태 업데이트*/
    vehicle_0_state.set_total_state(vehicle_0_next_state);
    vehicle_1_state.set_total_state(vehicle_1_next_state);
    vehicle_2_state.set_total_state(vehicle_2_next_state);
    vehicle_3_state.set_total_state(vehicle_3_next_state);
    vehicle_4_state.set_total_state(vehicle_4_next_state);

    
    /*시간 업데이트*/
    t += dt;    

    // std::cout << "t=" << t
    //       << " north=" << vehicle_0_next_state(0)
    //       << " easr="  << vehicle_0_next_state(1)
    //       << " down="  << vehicle_0_next_state(2)
    //       << " roll="  << rad2deg(vehicle_0_next_state(3))
    //       << " pitch=" << rad2deg(vehicle_0_next_state(4))
    //       << " speed=" << vehicle_0_next_state(6)
    //       << std::endl;


    }

    /*CSV 파일로 만들 값 저장*/

    vehicle_0_history.saveToCSV("../../make_csv/agent_0.csv");
    std::cout << "CSV file saved successfully!" << std::endl;
    
    vehicle_1_history.saveToCSV("../../make_csv/agent_1.csv");
    std::cout << "CSV file saved successfully!" << std::endl;
    
    vehicle_2_history.saveToCSV("../../make_csv/agent_2.csv");
    std::cout << "CSV file saved successfully!" << std::endl;
    
    vehicle_3_history.saveToCSV("../../make_csv/agent_3.csv");
    std::cout << "CSV file saved successfully!" << std::endl;
    
    vehicle_4_history.saveToCSV("../../make_csv/agent_4.csv");
    std::cout << "CSV file saved successfully!" << std::endl;












    /* 나중에 plot 최대 최소 허용 state을 반영하기 위한 코드임  */
     std::ofstream config("../../make_csv/aircraft_spec.json");
    config << "{\n"
        << "  \"max_speed\": " << g_FixedwingSpec.max_speed << ",\n"
        << "  \"min_speed\": " << g_FixedwingSpec.min_speed << ",\n"
        << "  \"max_roll\": " << g_FixedwingSpec.max_roll * 180.0 / M_PI << ",\n"
        << "  \"min_roll\": " << g_FixedwingSpec.min_roll * 180.0 / M_PI << ",\n"
        << "  \"max_pitch\": " << g_FixedwingSpec.max_pitch * 180.0 / M_PI << ",\n"
        << "  \"min_pitch\": " << g_FixedwingSpec.min_pitch * 180.0 / M_PI << ",\n"  // 쉼표 추가
        << "  \"max_p\": " << g_FixedwingSpec.p_max * 180.0 / M_PI << ",\n"  // 각도 변환 제거
        << "  \"min_p\": " << g_FixedwingSpec.p_min * 180.0 / M_PI<< ",\n"
        << "  \"max_q\": " << g_FixedwingSpec.q_max * 180.0 / M_PI<< ",\n"
        << "  \"min_q\": " << g_FixedwingSpec.q_min * 180.0 / M_PI<< ",\n"
        << "  \"max_r\": " << g_FixedwingSpec.r_max * 180.0 / M_PI<< ",\n"
        << "  \"min_r\": " << g_FixedwingSpec.r_min * 180.0 / M_PI<< ",\n"
        << "  \"max_at\": " << g_FixedwingSpec.at_max << ",\n"  // 각도 변환 제거
        << "  \"min_at\": " << g_FixedwingSpec.at_min << "\n"   // 마지막은 쉼표 없음
        << "}\n";
    config.close();


}