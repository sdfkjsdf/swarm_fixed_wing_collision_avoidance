#ifndef DYNAMICLINEARIZATION_H
#define DYNAMICLINEARIZATION_H
#include <fixed_wing_aircraft_model/FixedwingSpec.h>
#include<matrix/Matrix.hpp>


/*
 해당 코드는  "Zero-Order Control Barrier Functions for Sampled-Data Systems with State and Input Dependent Safety Constraints" 을 바탕으로 함



    xk+1 = ξ(T) = ADxk +BDBu+BDC

    A := ∂f/∂x|x=x{k}, B := g(x{k}),C := f(x{k}) − ∂f/∂x(x{k})*x{k}

    AD := eAT, BD := 적분 eA(T−τ)dτ

    m_Ad = AD
    m_Bd = BD



*/


class DynamicsLinearization
{

   public:
    DynamicsLinearization(const FixedwingSpec_t& spec, const double dt);
    ~DynamicsLinearization()=default;

    /*여기서는 지금 dx/dt=f(x)+g(x)u 에서의 f(x),g(x)을 직접 구하는 형태임*/

        void calculate_fx_gx_Jf_x(const matrix::Vector<double,11>& state);

    /*calculate_C 은 지금 C := f(xk) − {∂f/∂x(xk)}xk 을 구하는 함수 !! 여기서 반드시 먼저 calculate_Jf_x을 통해서 m_Jf_x을 받아야 함  그리고 지금 f(x) 는  모듈 내부에서 구해야 함  */
        void calculate_C(const matrix::Vector<double, 11 >& state,const matrix::Matrix<double,11,11>& m_Jf_x);
   /* calculate_Ad_Bd 는  AD := eAT, BD := 적분( eA(T−τ)dτ )을 의미함 !! 여기서 반드시 먼저 calculate_Jf_x을 통해서 m_Jf_x을 받아야 함 */
        void calculate_Ad_Bd();
        void calculate_BdB()
                {

                m_BdB=m_Bd*m_g_x;

                };

        void calculate_BdC()
                {
                    m_BdC= m_Bd*m_C;

                };

     void calculate_zoh_matrix(const matrix::Vector<double, 11 >& state);
     matrix::Vector<double,11> propagtion_zoh(const matrix::Vector<double,11>& state, const matrix::Vector<double,4>& control_input);
     
     /*여기서 지금 get을 쓰는 경우 반드시 void calculate_zoh_matrix 을 일차적으로 실행을 시켜야함*/
     matrix::Matrix<double,11,11> get_Ad(){return m_Ad;};
     matrix::Matrix<double,11,4> get_BdB(){return m_BdB;};
     matrix::Vector<double,11> get_BdC(){return m_BdC;};
     

    
   
  


  

    



  private:
     FixedwingSpec_t m_spec;
     double m_dt;
     matrix::Vector<double,11>m_f_x{};
     matrix::Matrix<double,11,4> m_g_x{};
     matrix::Matrix<double,11,11> m_Jf_x{};
     matrix::Matrix<double,11,11> m_Ad{};
     matrix::Matrix<double,11,11> m_Bd{};
     matrix::Matrix<double,11,4> m_BdB{};
     matrix::Vector<double,11> m_BdC{};
     matrix::Vector<double,11> m_C{};
     matrix::Vector<double,11> m_next_step();





};


#endif