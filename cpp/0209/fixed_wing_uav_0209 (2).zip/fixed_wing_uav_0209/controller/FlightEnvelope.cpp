
/*
작성자 : 이동혁    
작성날짜 : 2026/01/09일 
 기능 세부 설명 :  "Investigation of Practical Flight Envelope Protection Systemsfor Small Aircraft 논문 기반으로 고정익 무인기의  Flight envelop을 구현하는 내용

수정날짜 및 수정사항    
현재 남아 있는 내용은 지금 v_stall 이라는 실속속도를 구하는 과정에서 선회 상승 비행에서는 어떤식으로 해야 할 것인지를 잘 고민해보아야 함  
실속보호를 위한 각도가 지금 q_cmd에서 satruatiuon이 되는 것이 아닌 yawrate_sp 에서 saturation이 된느 구조임

해당 버전에서 달라진 것은 이전에는 그냥 지금 command limit 만 주었으면은 지금 해당 코드에서는 비행 영역 보호에 대한 즉각적인 
at_sp,p_sp의 범위를 제공해준다 -> 그리고 나서  ndi part에서 실질적으로 지금 cmd에 대한 제약범위를 다룰 예정임...


[수정이 된 내용]
: 2026/02/09일
-> 해당 원래의 논문에서는 v_stall을 roll각에 대한 state 의존성의 stall 속도를 구하는 것이 아니라
   임의의 상수로 설정하고 진행을 함

 */

#include <matrix/math.hpp>
#include <Fixed_wing_aircraft_model/FixedwingSpec.h>
#include <controller/FlightEnvelope.h>
#include <cmath>
#include <algorithm>



FlightEnvelope::FlightEnvelope(const FixedwingSpec_t& spec, const GainParameter_t& gain)
    :m_spec(spec),
     m_gain(gain)
    {}

 matrix::Vector<double,4> FlightEnvelope :: apply_FlightEnvelope(const matrix::Vector<double,11>& state,
                                                                 const double& roll_setpoint
                                                                 )
 {

    m_output_flightenvelope.setZero();

    /* 상태 값을 받아오기 */
    const double n = state(0);
    const double e = state(1);
    const double d = state(2);

    const double roll = state(3);
    const double pitch = state(4);
    const double yaw = state(5);
    const double speed = state(6);

    const double p = state(7);
    const double q = state(8);
    const double r = state(9);
    const double at = state(10);

    

     /*중력 및 항력 계수 받아오기*/

    const double g = m_spec.g;
    const double k_acc = m_spec.k_acc;

    /*지금 속도 보호을 위해서 일단 게인값을 받아오기*/
    const double k_v =m_gain.m_k_v;

    /*각도 변환 함수 시작 */
    const double c_r = std::cos(roll);
    const double s_r = std::sin(roll);
    const double c_p = std::cos(pitch);
    const double s_p = std::sin(pitch);
    const double c_y = std::cos(yaw);
    const double s_y = std::sin(yaw);
    const double tan_p = std::tan(pitch);

    /*기체 spec 관련 내용을 받아오기 */

    const double max_speed=m_spec.max_speed;
    const double min_speed=m_spec.min_speed;

    const double max_pitch=m_spec.max_pitch;
    const double min_pitch=m_spec.min_pitch;

  

    /*이전의 set point 값을 받아오기 */

    const double roll_sp=roll_setpoint;
  




    /* 실속속도 연산 */
    /* 지금 해당 부분은 수평선회 비행에서의 실속을 가정한 것이지만 나중에  선회 상승비행시에도 고려를 해야 한다*/
    //const double roll_fff = std::max(std::abs(roll_sp), std::abs(roll));

    
    //const double roll_fff=std::max(std::abs(roll),std::abs(roll_sp));
    //const double stall_gain=std::max( c_p/(std::cos(roll_fff)) ,1.0 );
    //const double stall_speed=min_speed*std::sqrt(stall_gain)+stall_margin_abs;
    const double speed_lowwer=min_speed;
    m_stall_speed=min_speed;

    /* 피치각 조절을 통한 속도 보호 */
     /* 지금  clamp 에러가 안 생길려면 최소 3이상으로 설정하는 것을 추천  */
  
   
    /*Stall 방지를 위한 피치각 상한 하한 조절 */
    const double pitch_upper=max_pitch * std::tanh(c1+(speed-speed_lowwer)/c2 );
    const double pitch_lowwer=min_pitch *std::tanh(c1+(max_speed-speed)/c2 );



   /*fep을 위한 at_sp에 대한 정보를 바로 주기*/

    const double at_sp_min=lyaponove_speed*(speed_lowwer-speed)+g*s_p+(k_acc*(speed*speed));
    const double at_sp_max=lyaponove_speed*(max_speed-speed)+g*s_p+(k_acc*(speed*speed));

   /*fep을 위한 q_sp에 대한 정보를 바로 주는 기능*/

   const double dot_pitch_sp_min=lyaponove_k*(pitch_lowwer-pitch);
   const double dot_pitch_sp_max=lyaponove_k*(pitch_upper-pitch);

   const double q_sp_min=(dot_pitch_sp_min+(r*s_r))/c_r;
   const double q_sp_max=(dot_pitch_sp_max+(r*s_r))/c_r;




   m_output_flightenvelope(0)=at_sp_min;
   m_output_flightenvelope(1)=at_sp_max;
   m_output_flightenvelope(2)=q_sp_min;
   m_output_flightenvelope(3)=q_sp_max;




    return  m_output_flightenvelope ;





 }
