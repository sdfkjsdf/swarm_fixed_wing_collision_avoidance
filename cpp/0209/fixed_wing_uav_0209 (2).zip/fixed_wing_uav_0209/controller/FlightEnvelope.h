#ifndef FLIGHTENVELOPE_H
#define FLIGHTENVELOPE_H
#include <matrix/math.hpp>
#include <Fixed_wing_aircraft_model/FixedwingSpec.h>
#include<controller/GainParameter.h>

/*이제부터는 지금 여기서 즉각적으로  at_cmd,q_cmd에 대한 제약조건을 바로 주는 것임
m_output_flightenvelope(0) -> 여기서 at_cmd에 대한  min 값임
m_output_flightenvelope(1) -> 여기서 at_cmd에 대한  max 값임
m_output_flightenvelope(3) -> 여기서 q_cmd에 대한  min 값임
m_output_flightenvelope(4) -> 여기서 q_cmd에 대한  max 값임

*/

constexpr double kPi = 3.14159265358979323846;






class FlightEnvelope
{
    public :
        FlightEnvelope(const FixedwingSpec_t& spec, const GainParameter_t& gain);
        ~FlightEnvelope()=default;

        matrix::Vector<double,4> apply_FlightEnvelope(const matrix::Vector<double,11>& state,
                                                      const double& roll_setpoint
                                                      );

                
        double get_stall_speed(){return m_stall_speed;};                                                
        double get_at_sp_min_fep(){return m_output_flightenvelope(0);};
        double get_at_sp_max_fep(){return m_output_flightenvelope(1);};
        double get_q_sp_min_fep(){return m_output_flightenvelope(2);};
        double get_q_sp_max_fep(){return m_output_flightenvelope(3);};

        



    private :
        
        /* 실속 에 해당되는 피치각을 구히기 위한 파라미터 */
        const double c1 = 3*kPi/180;  /* 경계면에서의 진동을 막기 위한 바운더리에 해당*/
        const double c2 = 10;
       /* 실속에 해당되는 피치각으로 의 진입을 막기 위한 게인 상수*/
        const double lyaponove_k = 0.5;
       /* 실속 방지용 가속도에 대한 내용*/
        const double lyaponove_speed=0.5;

        /*추력 채널에서 실속을 막기 위한 마진*/
        const double stall_margin_abs = 0.5; 

        FixedwingSpec_t m_spec;
        GainParameter_t m_gain;

        double m_stall_speed=0.0;
        matrix::Vector<double,4> m_output_flightenvelope{};

};


#endif