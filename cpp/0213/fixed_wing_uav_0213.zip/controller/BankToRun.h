#ifndef BANKTORUN_H
#define BANKTORUN_H

#include <Fixed_wing_aircraft_model/FixedwingSpec.h>
#include <cmath>
#include <controller/GainParameter.h>
#include <controller/NdiParameter.h>
#include <matrix/math.hpp>
#include <algorithm>




class BankToRun

{
    public:
         BankToRun(const FixedwingSpec_t& spec,const GainParameter_t& gain,const NdiParameter_t& ndi);
        ~BankToRun() = default; 

        void calculate_r_cmd_boundary(const matrix::Vector<double,11>& state, const double dt);

        double r_cmd_to_p_setpoint(const matrix::Vector<double,11>& state, const double r_cmd);

        double get_r_cmd_min(){return m_r_cmd_min;};
        double get_r_cmd_max(){return m_r_cmd_max;};




    


    private:
        
        const FixedwingSpec_t m_spec;
        const GainParameter_t m_gain;
        const NdiParameter_t m_ndi;
        double m_r_cmd_min=0.0;
        double m_r_cmd_max=0.0;
        double m_p_setpoint=0.0;



};







#endif