#include <controller/BankToRun.h>


BankToRun::BankToRun(const FixedwingSpec_t& spec,const GainParameter_t& gain,const NdiParameter_t& ndi)
:m_gain(gain),m_spec(spec),m_ndi(ndi){}


void BankToRun::calculate_r_cmd_boundary(const matrix::Vector<double,11>& state,const double dt)
{
    /* 상태 값을 받아오기 */
    const double n = state(0);
    const double e = state(1);
    const double d = state(2);

    const double roll = state(3);
    const double pitch = state(4);
    const double yaw = state(5);
    const double speed = state(6);

    const double p = state(7);
    const double q = state(8);
    const double r = state(9);
    const double at = state(10);

    /*각도 변환 함수 시작 */
    const double c_r = std::cos(roll);
    const double s_r = std::sin(roll);
    const double c_p = std::cos(pitch);
    const double s_p = std::sin(pitch);
    const double c_y = std::cos(yaw);
    const double s_y = std::sin(yaw);
    const double tan_p = std::tan(pitch);

    /*기체 spec 관련 내용을 받아오기 */
    const double max_roll=m_spec.max_roll;
    const double min_roll=m_spec.min_roll;
    const double g = m_spec.g;

    const double max_p=m_spec.p_max;
    const double min_p=m_spec.p_min;

    const double max_r=m_spec.r_max;
    const double min_r=m_spec.r_min;

    const double t_p = m_spec.timeconstant_p;
    const double t_r=m_spec.timeconstant_r;


    /*파라미터 상수 받아오기*/
    const double k_roll=m_gain.m_k_roll;
    const double k_r_sp=m_ndi.m_k_r_sp;

    /*조화 선회를 위한 r_setpoint 값 연산 시작*/
    const double p_trim = -( (q*s_r) + (r*c_r) )*tan_p;
    

    /*1차 지연 이산화 계수 구하기*/
    const double alpha_p = std::exp(-dt / t_p);
    const double alpha_r = std::exp(-dt / t_r);
    const double p_achievable_max = alpha_p * p + (1.0 - alpha_p) * max_p;
    const double p_achievable_min = alpha_p * p + (1.0 - alpha_p) * min_p;
    const double r_achievable_max = std::min(max_r ,alpha_r * r + (1.0 - alpha_r) * max_r );
    const double r_achievable_min = std::max(min_r , alpha_r * r + (1.0 - alpha_r) * min_r );




    const double roll_upper=std::min(max_roll,0.1*max_p*dt + roll);
    const double roll_lower=std::max(min_roll,0.1*min_p*dt + roll);
    
const double c_ru = std::cos(roll_upper);
const double s_ru = std::sin(roll_upper);
const double c_rl = std::cos(roll_lower);
const double s_rl = std::sin(roll_lower);
    

    const double yawrate_upper= (g*std::tan(roll_upper))/speed;
    const double yawrate_lower= (g*std::tan(roll_lower))/speed;


    const double r_setpoint_max=(yawrate_upper*c_p -q*s_r)/c_r;
    const double r_setpoint_min=(yawrate_lower*c_p -q*s_r)/c_r;


    const double r_setpoint_upper=std::min(r_achievable_max,r_setpoint_max);
    const double r_setpoint_lower=std::max(r_achievable_min,r_setpoint_min);
    

    const double dot_r_sp_max=k_r_sp*(r_setpoint_upper-r);
    const double dot_r_sp_min=k_r_sp*(r_setpoint_lower-r);

    m_r_cmd_max=std::min(max_r , r + (t_r*dot_r_sp_max));
    m_r_cmd_min=std::max(min_r , r + (t_r*dot_r_sp_min));


}


double BankToRun::r_cmd_to_p_setpoint(const matrix::Vector<double,11>& state, const double r_cmd)
{

    /* 상태 값을 받아오기 */
    const double n = state(0);
    const double e = state(1);
    const double d = state(2);

    const double roll = state(3);
    const double pitch = state(4);
    const double yaw = state(5);
    const double speed = state(6);

    const double p = state(7);
    const double q = state(8);
    const double r = state(9);
    const double at = state(10);

    /*각도 변환 함수 시작 */
    const double c_r = std::cos(roll);
    const double s_r = std::sin(roll);
    const double c_p = std::cos(pitch);
    const double s_p = std::sin(pitch);
    const double c_y = std::cos(yaw);
    const double s_y = std::sin(yaw);
    const double tan_p = std::tan(pitch);

     /*기체 spec 관련 내용을 받아오기 */
    const double max_roll=m_spec.max_roll;
    const double min_roll=m_spec.min_roll;
    const double g = m_spec.g;

    /*파라미터 상수 받아오기*/
    const double k_roll=m_gain.m_k_roll;
    const double k_r_sp=m_ndi.m_k_r_sp;
    const double t_r=m_spec.timeconstant_r;

    /*NDI 에서의 p_trim 값을 연산*/
    const double p_trim = -( (q*s_r) + (r*c_r) )*tan_p;

    /*조화 선회를 위한 r_setpoint 값 연산 시작*/

    const double r_setpoint=(-r+r_cmd)/(t_r*k_r_sp)+r;

    const double yawrate_setpoint=( (q*s_r) + (r_setpoint*c_r) )/c_p;

    const double roll_setpoint=std::atan((speed*yawrate_setpoint)/g);

    const double p_setpoint = k_roll*(roll_setpoint-roll)+p_trim;

    return p_setpoint;


    /* r_cmd을 통해서 역으로 r_setpoint을 구하기*/


}