#ifndef COORDINATED_TURN_LOG_H
#define COORDINATED_TURN_LOG_H

#include <matrix/math.hpp>
#include <vector>
#include <fstream>
#include <cmath>

struct CoordTurnData_t {
    double time;
    double roll_deg;           // 실제 롤각
    double roll_coord_deg;     // 조화선회를 위한 필요 롤각 (추가)
    double roll_error_deg;     // 롤각 오차 (추가)
    double speed;
    double psi_dot_coord;      // 이론 yaw rate (deg/s)
    double psi_dot_actual;     // 실제 yaw rate (deg/s)
    double coord_error;        // yaw rate 오차 (deg/s)
};

class CoordinatedTurnLog {
public:
    CoordinatedTurnLog(int id, double gravity = 9.81) 
        : m_agent_id(id), m_g(gravity) {}

    void addData(double t, const matrix::Vector<double, 11>& state) {
        constexpr double rad2deg = 180.0 / 3.14159265358979323846;
        
        const double roll = state(3);
        const double pitch = state(4);
        const double speed = state(6);
        const double q = state(8);
        const double r = state(9);

        CoordTurnData_t d;
        d.time = t;
        d.roll_deg = roll * rad2deg;
        d.speed = speed;
        
        // 이론적 조화선회 yaw rate: psi_dot = (g/V) * tan(phi)
        d.psi_dot_coord = (m_g / speed) * std::tan(roll) * rad2deg;
        
        // 실제 yaw rate: (q*sin(phi) + r*cos(phi)) / cos(theta)
        const double psi_dot_actual_rad = (q * std::sin(roll) + r * std::cos(roll)) / std::cos(pitch);
        d.psi_dot_actual = psi_dot_actual_rad * rad2deg;
        
        // yaw rate 오차
        d.coord_error = d.psi_dot_actual - d.psi_dot_coord;

        // 조화선회를 위한 필요 롤각: phi_coord = atan((V * psi_dot_actual) / g)
        const double roll_coord_rad = std::atan((speed * psi_dot_actual_rad) / m_g);
        d.roll_coord_deg = roll_coord_rad * rad2deg;
        
        // 롤각 오차
        d.roll_error_deg = d.roll_deg - d.roll_coord_deg;

        m_data.push_back(d);
    }

    void saveToCSV(const std::string& filename) {
        std::ofstream csv(filename);
        csv << "time,roll_deg,roll_coord_deg,roll_error_deg,speed,psi_dot_coord,psi_dot_actual,coord_error\n";
        
        for (const auto& d : m_data) {
            csv << d.time << ","
                << d.roll_deg << ","
                << d.roll_coord_deg << ","
                << d.roll_error_deg << ","
                << d.speed << ","
                << d.psi_dot_coord << ","
                << d.psi_dot_actual << ","
                << d.coord_error << "\n";
        }
        csv.close();
    }

private:
    int m_agent_id;
    double m_g;
    std::vector<CoordTurnData_t> m_data;
};

#endif