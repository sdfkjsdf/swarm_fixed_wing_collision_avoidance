import pandas as pd
import matplotlib.pyplot as plt

# 에이전트 설정
num_agents = 5
colors = ['blue', 'orange', 'green', 'red', 'purple']

# 모든 에이전트 데이터 로드
dfs = []
for i in range(num_agents):
    df = pd.read_csv(f'make_csv/coordinated_turn_agent_{i}.csv')
    dfs.append(df)

time = dfs[0]['time']

# 첫 번째 창: Yaw Rate 이론 vs 실제 (에이전트별)
fig1 = plt.figure(figsize=(14, 10))
fig1.suptitle('Yaw Rate: Theory vs Actual', fontsize=16)

for i in range(num_agents):
    plt.subplot(3, 2, i + 1)
    plt.plot(time, dfs[i]['psi_dot_coord'], label='Theory', color='blue', linewidth=1.5)
    plt.plot(time, dfs[i]['psi_dot_actual'], label='Actual', color='red', linewidth=1.5, linestyle='--')
    plt.xlabel('Time (s)')
    plt.ylabel('Yaw Rate (deg/s)')
    plt.title(f'Agent {i}')
    plt.legend(fontsize=8)
    plt.grid(True, alpha=0.3)

plt.tight_layout()

# 두 번째 창: Roll Angle 이론 vs 실제 (에이전트별)
fig2 = plt.figure(figsize=(14, 10))
fig2.suptitle('Roll Angle: Theory vs Actual', fontsize=16)

for i in range(num_agents):
    plt.subplot(3, 2, i + 1)
    plt.plot(time, dfs[i]['roll_coord_deg'], label='Theory (Required)', color='blue', linewidth=1.5)
    plt.plot(time, dfs[i]['roll_deg'], label='Actual', color='red', linewidth=1.5, linestyle='--')
    plt.xlabel('Time (s)')
    plt.ylabel('Roll (deg)')
    plt.title(f'Agent {i}')
    plt.legend(fontsize=8)
    plt.grid(True, alpha=0.3)

plt.tight_layout()

# 세 번째 창: Roll 오차 (에이전트별 서브플롯)
fig3 = plt.figure(figsize=(14, 10))
fig3.suptitle('Roll Angle Error: Actual - Theory', fontsize=16)

for i in range(num_agents):
    plt.subplot(3, 2, i + 1)
    plt.plot(time, dfs[i]['roll_error_deg'], color=colors[i], linewidth=1.5)
    plt.axhline(y=0, color='black', linestyle='--', linewidth=1, alpha=0.5)
    plt.xlabel('Time (s)')
    plt.ylabel('Roll Error (deg)')
    plt.title(f'Agent {i}')
    plt.grid(True, alpha=0.3)

plt.tight_layout()

# 네 번째 창: Yaw Rate 오차 (에이전트별 서브플롯)
fig4 = plt.figure(figsize=(14, 10))
fig4.suptitle('Yaw Rate Error: Actual - Theory', fontsize=16)

for i in range(num_agents):
    plt.subplot(3, 2, i + 1)
    plt.plot(time, dfs[i]['coord_error'], color=colors[i], linewidth=1.5)
    plt.axhline(y=0, color='black', linestyle='--', linewidth=1, alpha=0.5)
    plt.xlabel('Time (s)')
    plt.ylabel('Yaw Rate Error (deg/s)')
    plt.title(f'Agent {i}')
    plt.grid(True, alpha=0.3)

plt.tight_layout()

plt.show()