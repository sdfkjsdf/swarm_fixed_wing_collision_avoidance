#include <iostream>
#include <fstream>
#include <random>
#include <cmath>

int main() {
    const int total_vehicle_num = 5;
    const double kPi = 3.14159265358979323846;
    
    const std::string output_file = "../../build_initial_condition/initial_conditions.txt";
    
    std::random_device rd;
    unsigned int seed = rd();
    std::mt19937 gen(seed);
    
    std::uniform_real_distribution<> north_dist(-5000, 5000);
    std::uniform_real_distribution<> east_dist(-5000, 5000);
    std::uniform_real_distribution<> down_dist(-0.01, 0.01); 
    std::uniform_real_distribution<> yaw_dist(-0.00001,0.00001);
    std::uniform_real_distribution<> speed_dist(25, 35);
    
    std::ofstream file(output_file);
    if (!file.is_open()) {
        std::cerr << "Failed to create file: " << output_file << std::endl;
        return 1;
    }
    
    file << "# Seed: " << seed << std::endl;
    file << "# Agent_ID, North, East, Down, Yaw(rad), Speed\n";
    
    for (int i = 0; i < total_vehicle_num; i++) {
        file << i << ", " 
             << north_dist(gen) << ", " 
             << east_dist(gen) << ", " 
             << down_dist(gen) << ", "
             << yaw_dist(gen) << ", " 
             << speed_dist(gen) << "\n";
    }
    
    file.close();
    
    std::cout << "Initial conditions generated successfully!" << std::endl;
    std::cout << "Seed: " << seed << std::endl;
    std::cout << "File: " << output_file << std::endl;
    
    return 0;
}