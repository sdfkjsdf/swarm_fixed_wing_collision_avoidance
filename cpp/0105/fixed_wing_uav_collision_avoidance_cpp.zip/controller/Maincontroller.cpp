#include "MainController.h"
#include <cmath>
#include <algorithm>

MainController::MainController(
    const FixedwingSpec_t& spec,
    const GainParameter_t& gain,
    const NdiParameter_t& ndi
) : 
     m_spec(spec),
    m_gain(gain),
    m_ndi(ndi),
    m_rollpitchyawratesetpoint(spec, gain),
    m_rollratepitchratesetpoint(gain),        
    m_flightenvelope(spec),
    m_bodyaxisratesetpoint(spec),
    m_thrustsetpoint(spec,gain)
   
{}

matrix::Vector<double, 4> MainController::calculate_control_input(
    const matrix::Vector<double, 11>& state,
    const matrix::Vector<double, 11>& setpoint)
    { 
         m_output_maincontroller.setZero();
        /*초기 각 변환 선언*/


                /* state 형태  */
                    // const double n = state(0);
                    // const double e = state(1);
                    // const double d = state(2);

                    // const double roll = state(3);
                    // const double pitch = state(4);
                    // const double yaw = state(5);
                    // const double speed = state(6);

                    // const double p = state(7);
                    // const double q = state(8);
                    // const double r = state(9);
                    // const double at = state(10);


                /* Setpoint 형태 */
                    // const double n_set=setpoint(0);
                    // const double e_set=setpoint(1);
                    // const double d_set=setpoint(2);
                    // const double v_set=setpoint(3);

     /*roll 각 setpoitn pitch각 setpoint pitchrate setpoint을 구하는 내용 */

       m_rollpitchyawratesetpoint.calculate_roll_pitch_yawrate_sp(state,setpoint );
       /* 나중에 flocking 이나 formation control 에서 기억해야 하는 내용*/
        /* RollPitchYawrateSetpoint.cpp의 하단 부분의 */
        /* const double error_n = n_set - n ;
        const double error_e = e_set - e ;
        const double yaw_sp=std::atan2(error_e,error_n);
        const double yaw_error= std::atan2(std::sin(yaw_sp-yaw),std::cos(yaw_sp-yaw));
        const double dot_yaw_rar= k_yaw*yaw_error; */
        /* 이거 연산 과정 대신에 지금 그냥 바로 dot_yaw_rar을 입력해주면 된다 그러면 나머지는 알아서 구해짐 */

        /* 다만 주의해야 할 것은 고도 관련 피치각 제어는 따로 채널을 만들어서 한다는 가정하에 출력이 되는 것은 roll_sp,yawrate_sp,dv_sp/dt 가 나옴 */
        /* 따라서 지금 이 주석 이후로 부터는 동일하지만 앞단에서 잘 분리 시켜서 알맞게 주어야 함 */







       const matrix::Vector<double, 2> roll_pitch_setpoint_before_fev=  m_rollpitchyawratesetpoint.get_roll_pitch_set();
       const double yawrate_setpoint =m_rollpitchyawratesetpoint.get_yawrate_set(); /* 지금 이것은 크게 변화하지 않고 나중에 결합이 되어서 사용*/
            /*roll_pitch_setpoint_before_fev(0)이 flight envelope 적용 전의 roll각의 setpoint */
            /*roll_pitch_setpoint_before_fev(1)이 flight envelope 적용 전의 pitch각의 setpoint */


    /* 비행영역 보호 시작 */

     m_flightenvelope.apply_FlightEnvelope(state,roll_pitch_setpoint_before_fev,setpoint(6));

        const double speed_setpoint_after_fev =m_flightenvelope.get_speed_after_fev();
        const double pitch_setpoint_after_fev =m_flightenvelope.get_pitch_sp_after_fev();
        const double lyapunov_function_value_pitch_fev=m_flightenvelope.get_fev_pitch();
        const double gradient_lyapunov = m_flightenvelope.get_gradient_envelope_pitch();

     matrix::Vector<double,2> roll_pitch_setpoint_after_fev{};
        roll_pitch_setpoint_after_fev(0)=roll_pitch_setpoint_before_fev(0);
        roll_pitch_setpoint_after_fev(1)=pitch_setpoint_after_fev;

    /*rollrate,pitchrate,yawrate 연산 및 결합*/
     m_rollratepitchratesetpoint.calculate_rollrate_pitchrate(state,roll_pitch_setpoint_after_fev);

        const double rollrate_setpoint=m_rollratepitchratesetpoint.get_rollrate_sp();
        const double pitchrate_setpoint=m_rollratepitchratesetpoint.get_pitchrate_sp();

     matrix::Vector<double,3> setpoint_rate_of_roll_pitch_yaw{};

        setpoint_rate_of_roll_pitch_yaw(0)=rollrate_setpoint;
        setpoint_rate_of_roll_pitch_yaw(1)=pitchrate_setpoint;
        setpoint_rate_of_roll_pitch_yaw(2)=yawrate_setpoint;


    /*Body axis rate 연산*/
    
    m_bodyaxisratesetpoint.calculate_bodyaxisrate(state,setpoint_rate_of_roll_pitch_yaw);

        const double p_setpoint=m_bodyaxisratesetpoint.get_p_setpoint();
              double q_setpoint=m_bodyaxisratesetpoint.get_q_setpoint(); /* 여기서 const 을 안한 이유는 나종에  lyapunov_function_value_pitch_fev,  gradient_lyapunov 이거에 따라서 saturattion 됨 */
        const double r_setpoint=m_bodyaxisratesetpoint.get_r_setpoint(); 

    

    /* thrust channel 연산 */
    m_thrustsetpoint.calculate_at_sp(state,speed_setpoint_after_fev);
        const double at_setpoint=m_thrustsetpoint.get_at_sp();


    /* NDI 시작*/
        const double p = state(7);
        const double q = state(8);
        const double r = state(9);
        const double at = state(10);



        const double t_p =m_spec.timeconstant_p;
        const double t_q =m_spec.timeconstant_q;
        const double t_r =m_spec.timeconstant_r;
        const double t_a =m_spec.timeconstant_at;

        const double p_max=m_spec.p_max;
        const double q_max=m_spec.q_max;
        const double r_max=m_spec.r_max;
        const double at_max=m_spec.at_max;

        const double p_min=m_spec.p_min;
        const double q_min=m_spec.q_min;
        const double r_min=m_spec.r_min;
        const double at_min=m_spec.at_min;

        const double k_p_sp=m_ndi.k_p_sp;
        const double k_q_sp=m_ndi.k_q_sp;
        const double k_r_sp=m_ndi.k_r_sp;
        const double k_at_sp=m_ndi.k_at_sp;

        /* flight envelope 구문 시작*/

        const double g_tol = 1e-6;

        const double g   = lyapunov_function_value_pitch_fev;
        const double rgq = gradient_lyapunov * q_setpoint;

        if (g < -g_tol) {
             (void)0; 
        }
        else if (rgq <= 0.0) {
              (void)0; 
        }
        else {
            q_setpoint = 0.0;
        }

        const double dot_p_sp=k_p_sp*(p_setpoint-p);
        const double dot_q_sp=k_q_sp*(q_setpoint-q);
        const double dot_r_sp=k_r_sp*(r_setpoint-r);
        const double dot_at_sp=k_at_sp*(at_setpoint-at);

        const double p_cmd_rar = p + (t_p*dot_p_sp);
        const double q_cmd_rar = q + (t_q*dot_q_sp);
        const double r_cmd_rar = r + (t_r*dot_r_sp);
        const double at_cmd_rar= at+ (t_a*dot_at_sp);

        const double p_cmd= std::clamp(p_cmd_rar,p_min,p_max);
        const double q_cmd= std::clamp(q_cmd_rar,q_min,q_max);
        const double r_cmd= std::clamp(r_cmd_rar,r_min,r_max);
        const double at_cmd =std::clamp(at_cmd_rar,at_min,at_max);

    m_output_maincontroller(0)=p_cmd;
    m_output_maincontroller(1)=q_cmd;
    m_output_maincontroller(2)=r_cmd;
    m_output_maincontroller(3)=at_cmd;


    return m_output_maincontroller;



    }