#ifndef ROLLPITCHYAWRATESETPOINT_H
#define ROLLPITCHYAWRATESETPOINT_H

#include <matrix/math.hpp>
#include <Fixed_wing_aircraft_model/FixedwingSpec.h>
#include <controller/GainParameter.h>

class RollPitchYawrateSetpoint
{
public:
    RollPitchYawrateSetpoint(const FixedwingSpec_t& spec, const GainParameter_t& gain);
    ~RollPitchYawrateSetpoint() = default;
    
    matrix::Vector<double, 3> calculate_roll_pitch_yawrate_sp(const matrix::Vector<double, 11>& state, const matrix::Vector<double, 11>& setpoint);
    
    matrix::Vector<double, 2> get_roll_pitch_set() const { return m_roll_pitch_yawrate_sp.slice<2,1>(0,0); } 
    /* get_roll_pitch_set 의 출력값을 나중에 RollratePitchrateSetpoint에 입력으로 주면 됨 */
    double get_yawrate_set() const { return m_roll_pitch_yawrate_sp(2); }
    /*get_yawrate_set의 출력값은 나중에 RollratePitchrateSetpoint와 합쳐져서 3*1 벡터로 생성이 됨   */

private:

    FixedwingSpec_t m_spec;
    GainParameter_t m_gain;
    matrix::Vector<double, 3> m_roll_pitch_yawrate_sp{}; 
    
};

#endif // [수정] 공백 제거