#include <controller/RollratePitchrateSetpoint.h>

RollratePitchrateSetpoint::RollratePitchrateSetpoint(const GainParameter_t& gain)
    :m_gain(gain){}

 matrix::Vector<double,2>RollratePitchrateSetpoint::calculate_rollrate_pitchrate(const matrix::Vector<double,11>& state,const matrix::Vector<double,2>& roll_pitch_sp)
 {
    m_output_rate_of_rollpitch.setZero();

    const double n = state(0);
    const double e = state(1);
    const double d = state(2);

    const double roll = state(3);
    const double pitch = state(4);
    const double yaw = state(5);
    const double speed = state(6);

    const double p = state(7);
    const double q = state(8);
    const double r = state(9);
    const double at = state(10);

    const double k_roll =m_gain.k_roll ;
    const double k_pitch =m_gain.k_pitch ;


    const double roll_sp  = roll_pitch_sp(0);
    const double pitch_sp = roll_pitch_sp(1);

    const double rollrate_sp=k_roll*(roll_sp-roll);
    const double pitchrate_sp=k_pitch*(pitch_sp-pitch);

    m_output_rate_of_rollpitch(0)=rollrate_sp;
    m_output_rate_of_rollpitch(1)=pitchrate_sp;

    return m_output_rate_of_rollpitch;




 }
