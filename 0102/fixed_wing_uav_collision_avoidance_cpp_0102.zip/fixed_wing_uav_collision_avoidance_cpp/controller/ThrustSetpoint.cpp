#include <algorithm>
#include <controller/ThrustSetpoint.h>
#include <cmath>

ThrustSetpoint::ThrustSetpoint(const FixedwingSpec_t& spec, const GainParameter_t& gain )
        :m_spec(spec),
         m_gain(gain)
        {}

double ThrustSetpoint:: calculate_at_sp(const matrix::Vector<double,11>& state ,  const double speed_setpoint)
{ 
    const double pitch = state(4);
    const double speed = state(6);



    const double s_p = std::sin(pitch);


    const double at_max=m_spec.at_max;
    const double at_min=m_spec.at_min;

    const double g = m_spec.g;
    const double k_acc = m_spec.k_acc;
    
    const double k_v =m_gain.k_v ;

    const double error_speed= speed_setpoint-speed;
    const double dot_error_speed= k_v*error_speed;

    const double at_setpoint_rar= dot_error_speed +(g*s_p)+(k_acc * (speed*speed) );

    m_at_sp=std::clamp(at_setpoint_rar,at_min,at_max );

    return m_at_sp;
    








}
