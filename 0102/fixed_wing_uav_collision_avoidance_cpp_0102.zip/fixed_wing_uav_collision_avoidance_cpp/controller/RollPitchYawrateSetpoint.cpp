#include <matrix/math.hpp>
#include "RollPitchYawrateSetpoint.h"
#include <Fixed_wing_aircraft_model/FixedwingSpec.h>
#include <controller/GainParameter.h>
#include <cmath>
#include <algorithm>

RollPitchYawrateSetpoint::RollPitchYawrateSetpoint(const FixedwingSpec_t& spec, const GainParameter_t& gain)
        :m_spec(spec),
        m_gain(gain)
{

}


 matrix::Vector<double, 3> RollPitchYawrateSetpoint::calculate_roll_pitch_yawrate_sp(const matrix::Vector<double, 11>& state, const matrix::Vector<double, 11>& setpoint)

 {

    m_roll_pitch_yawrate_sp.setZero();

    /* 상태 값을 받아오기 */
    const double n = state(0);
    const double e = state(1);
    const double d = state(2);

    const double roll = state(3);
    const double pitch = state(4);
    const double yaw = state(5);
    const double speed = state(6);

    const double p = state(7);
    const double q = state(8);
    const double r = state(9);
    const double at = state(10);


    /*각도 변환 함수 시작 */
    const double c_r = std::cos(roll);
    const double s_r = std::sin(roll);
    const double c_p = std::cos(pitch);
    const double s_p = std::sin(pitch);
    const double c_y = std::cos(yaw);
    const double s_y = std::sin(yaw);
    const double tan_p = std::tan(pitch);


    /*기체 spec 관련 내용을 받아오기 */

    const double max_roll=m_spec.max_roll;
    const double min_roll=m_spec.min_roll;

    const double max_pitch=m_spec.max_pitch;
    const double min_pitch=m_spec.min_pitch;

    const double g = m_spec.g;
    


    /* set point 받아오기 */

    const double n_set=setpoint(0);
    const double e_set=setpoint(1);
    const double d_set=setpoint(2);


    /*gain 파라미터 받아오기 */
    const double k_yaw =m_gain.k_yaw ; /* 해당 k_yaw는 실질적으로 위치에 대한 setpoint으로 유도항법을 진행하는 느낌 따라서 만약에 직접적으로  dot_yaw_rate을 받는 구조라면은 해당 k_yaw 없애고 바로 대입을 하는 구조로 나옴*/
    // const double k_yaw =0.0;
    const double k_d =m_gain.k_d ;


    /* 실질적인 구문 시작 */


    /*yawrate_sp, roll_sp을 구하는 과정*/
    const double error_n = n_set - n ;
    const double error_e = e_set - e ;
    const double yaw_sp=std::atan2(error_e,error_n);
    const double yaw_error= std::atan2(std::sin(yaw_sp-yaw),std::cos(yaw_sp-yaw));
    const double dot_yaw_rar= k_yaw*yaw_error;
    const double dot_yaw_max=(g*std::tan(max_roll)) *(c_p/speed);
    const double dot_yaw_min=(g*std::tan(min_roll)) *(c_p/speed);
    const double yawrate_sp = std::clamp(dot_yaw_rar, dot_yaw_min, dot_yaw_max);
    const double roll_sp=std::clamp(std::tanh( (speed * yawrate_sp*c_p )/g ),min_roll,max_roll );



    /*pitch_sp을 구하는 과정 */

    const double error_d=d_set-d;
    const double dot_error_d=k_d*error_d;
    const double arg = std::clamp((dot_error_d/speed),-1.0,1.0);
    const double pitch_sp_rar=-std::asin(arg);

    const double pitch_sp=std::clamp(pitch_sp_rar,min_pitch,max_pitch);

    m_roll_pitch_yawrate_sp(0)=roll_sp;
    m_roll_pitch_yawrate_sp(1)=pitch_sp;
    m_roll_pitch_yawrate_sp(2)=yawrate_sp;


    return m_roll_pitch_yawrate_sp ;






 }