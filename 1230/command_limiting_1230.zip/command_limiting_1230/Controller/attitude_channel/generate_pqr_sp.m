function [pqr_sp] = generate_pqr_sp(state,dot_sp_roll_pitch_yaw,spec_constraint)


% 여기서 dot_roll_pitch_yaw 의 차원은 3*1
if length(dot_sp_roll_pitch_yaw) ~=3
    disp("euler_rate_to_body_rate")
end

pqr_sp=zeros(3,1);

%  pqr_cmd=[p_sp 
%           q_sp
%           r_sp];



%% 상태 차원 정의 
     n=state(1);
     e=state(2);
     d=state(3);
     roll=state(4);
     pitch=state(5);
     yaw=state(6);
     v=state(7);
     p=state(8);
     q=state(9);
     r=state(10);
     at=state(11);

 %% 각변환 정의
     c_p=cos(pitch);
     s_p=sin(pitch);
     divide_c_p=1/c_p;
     c_y=cos(yaw);
     s_y=sin(yaw);
     c_r=cos(roll);
     s_r=sin(roll);
     tan_pitch=tan(pitch);


%% spec constraint 받아오기
  
  v_max=spec_constraint(1,1);
  v_min=spec_constraint(2,1);
  pitch_max=spec_constraint(3,1);
  pitch_min=spec_constraint(4,1);
  roll_max=spec_constraint(5,1);
  roll_min=spec_constraint(6,1);
  p_max=spec_constraint(7,1);
  p_min=spec_constraint(8,1);
  q_max=spec_constraint(9,1);
  q_min=spec_constraint(10,1);
  r_max=spec_constraint(11,1);
  r_min=spec_constraint(12,1);
  at_max = spec_constraint(13,1);
  at_min = spec_constraint(14,1);





%% 실제 시작

translation_matrix=zeros(3,3);

translation_matrix(1,1) = 1;
translation_matrix(1,2) = 0;
translation_matrix(1,3) = -s_p;

translation_matrix(2,1) = 0;
translation_matrix(2,2) = c_r;
translation_matrix(2,3) = c_p*s_r;

translation_matrix(3,1) = 0;
translation_matrix(3,2) = -s_r;
translation_matrix(3,3) = c_p*c_r;


pqr_sp_rar=translation_matrix*dot_sp_roll_pitch_yaw;  % 아직 지금 saturation을 안한 버전임


% saturation start 
pqr_sp(1,1)=min(max(pqr_sp_rar(1,1),p_min),p_max);
pqr_sp(2,1)=min(max(pqr_sp_rar(2,1),q_min),q_max);
pqr_sp(3,1)=min(max(pqr_sp_rar(3,1),r_min),r_max);





end

