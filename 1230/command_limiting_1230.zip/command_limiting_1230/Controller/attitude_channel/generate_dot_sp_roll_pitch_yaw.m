function [dot_sp_roll_pitch] = generate_dot_sp_roll_pitch_yaw(state,set_point_roll_pitch,gravity_drag,gain_parameter_attitude)

dot_sp_roll_pitch=zeros(2,1);

roll_sp=set_point_roll_pitch(1,1);
pitch_sp=set_point_roll_pitch(2,1);


%% gain 값 선언
  k_yaw=gain_parameter_attitude(1,1);   % 해당 gain은 yaw_error을 통해서 d(yaw_error)/dt을 구함
  k_roll=gain_parameter_attitude(2,1);  % 해당 gain 은 dot_roll_sp=k_roll*(roll_sp-roll); 을 만들 때 사용
  k_d=gain_parameter_attitude(3,1);     % 해당 gain은 error_d=d_set-d; dot_error_d=k_d*(error_d); 을 만들 떄 사용
  k_pitch=gain_parameter_attitude(4,1); % 해당 gain은  dot_pitch_sp=k_pitch*(pitch_sp-pitch);을 만들 떄 사용






%% 상태 차원 선언 관련 내용
    n=state(1);
    e=state(2);
    d=state(3);
    roll=state(4);
    pitch=state(5);
    yaw=state(6);
    v=state(7);
    p=state(8);
    q=state(9);
    r=state(10);
    at=state(11);


%% 각 변환에 자주 쓰는 내용 선언 
    c_p=cos(pitch);
    s_p=sin(pitch);
    divide_c_p=1/c_p;
    c_y=cos(yaw);
    s_y=sin(yaw);
    c_r=cos(roll);
    s_r=sin(roll);
    tan_pitch=tan(pitch);



%% 중력 및 항력계수 설정
   g=gravity_drag(1,1);
   k_acc = gravity_drag(2,1);

%% dot roll_setpoint 을 설정하는 법

    dot_roll_sp=k_roll*(roll_sp-roll);

%%  dot_pitch_sp을 구하는 법

    dot_pitch_sp=k_pitch*(pitch_sp-pitch); 

    dot_sp_roll_pitch=[dot_roll_sp;dot_pitch_sp];











    









end

