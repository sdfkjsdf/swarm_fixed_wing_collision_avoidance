function [set_point_roll_pitch,dot_yaw_set] = generate_roll_pitch_sp(state,set_point,spec_constraint,gain_parameter_attitude,gravity_drag)
%% 상태 차원 선언 관련 내용
    n=state(1);
    e=state(2);
    d=state(3);
    roll=state(4);
    pitch=state(5);
    yaw=state(6);
    v=state(7);
    p=state(8);
    q=state(9);
    r=state(10);
    at=state(11);


%% 각 변환에 자주 쓰는 내용 선언 
    c_p=cos(pitch);
    s_p=sin(pitch);
    divide_c_p=1/c_p;
    c_y=cos(yaw);
    s_y=sin(yaw);
    c_r=cos(roll);
    s_r=sin(roll);
    tan_pitch=tan(pitch);

%% setpoint 설정 
    n_set = set_point(1,1) ;
    e_set = set_point(2,1) ;
    d_set = set_point(3,1) ;
    v_set = set_point(7,1) ; 


% %% 중력 및 항력계수 설정
   g=gravity_drag(1,1);
   k_acc = gravity_drag(2,1);

%% 기체 spec 제약조건 선언
   v_max=spec_constraint(1,1);
   v_min=spec_constraint(2,1);
   pitch_max=spec_constraint(3,1);
   pitch_min=spec_constraint(4,1);
   roll_max=spec_constraint(5,1);
   roll_min=spec_constraint(6,1);
   p_max=spec_constraint(7,1);
   p_min=spec_constraint(8,1);
   q_max=spec_constraint(9,1);
   q_min=spec_constraint(10,1);
   r_max=spec_constraint(11,1);
   r_min=spec_constraint(12,1);
   at_max = spec_constraint(13,1);
   at_min = spec_constraint(14,1);

%% gain 값 선언
  k_yaw=gain_parameter_attitude(1,1);   % 해당 gain은 yaw_error을 통해서 d(yaw_error)/dt을 구함
  k_roll=gain_parameter_attitude(2,1);  % 해당 gain 은 dot_roll_sp=k_roll*(roll_sp-roll); 을 만들 때 사용
  k_d=gain_parameter_attitude(3,1);     % 해당 gain은 error_d=d_set-d; dot_error_d=k_d*(error_d); 을 만들 떄 사용
  k_pitch=gain_parameter_attitude(4,1); % 해당 gain은  dot_pitch_sp=k_pitch*(pitch_sp-pitch);을 만들 떄 사용


%% roll_setpoint 을 설정하는 법

    error_n = n_set - n ;
    error_e = e_set - e ;
    yaw_set= atan2(error_e,error_n);
    yaw_error=atan2(sin(yaw_set-yaw),cos(yaw_set-yaw));
    %dot_yaw_sp_rar=k_yaw*yaw_error; % 만약에 지금 직접적으로 줄 예정이면은 그냥 dot_yaw_sp에 바로 넣으면 됨
    dot_yaw_sp_rar=0;

    dot_yaw_min=(g*tan(roll_min))*c_p/v;
    dot_yaw_max=(g*tan(roll_max))*c_p/v;

    dot_yaw_sp=min(max(dot_yaw_sp_rar,dot_yaw_min),dot_yaw_max);


    roll_sp=tanh(  (v*dot_yaw_sp* c_p )/(g)   );




%% pitch_sp을 구하는 법

    error_d=d_set-d;
    dot_error_d=k_d*(error_d); 

    % 지금 asin 들어가기 전에 saturation
    arg=min(max(dot_error_d/v,-1),1);
    pitch_sp_rar=-asin(arg); % 현재 spec에 대해서 saturation을 안한 값
    pitch_sp=min(max(pitch_sp_rar,pitch_min),pitch_max); % 현재 spec에 대해서 saturation이 된 값

 
    set_point_roll_pitch=[roll_sp;pitch_sp];

    dot_yaw_set=dot_yaw_sp;







end

