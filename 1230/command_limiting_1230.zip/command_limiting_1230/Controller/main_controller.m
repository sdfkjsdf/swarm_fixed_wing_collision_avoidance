function [control_input] = main_controller(state,set_point,gravity_drag,spec_constraint,gain_parameter_attitude,gain_parameter_thrust,ndi_parameter,time_constant)
control_input=zeros(4,1);

% 아직 at_cmd을 안 구현함 


%% state get set
    n=state(1);
    e=state(2);
    d=state(3);
    roll=state(4);
    pitch=state(5);
    yaw=state(6);
    v=state(7);
    p=state(8);
    q=state(9);
    r=state(10);
    at=state(11);

%% 시상수 get,set
    t_p=time_constant(1,1);
    t_q=time_constant(2,1);
    t_r=time_constant(3,1);
    t_a=time_constant(4,1);
 
%% NDI 파라미터 get,set

    k_p_sp=ndi_parameter(1,1);
    k_q_sp=ndi_parameter(2,1);
    k_r_sp=ndi_parameter(3,1);
    k_at_sp=ndi_parameter(4,1);

%% spec constraint get set

  v_max=spec_constraint(1,1);
  v_min=spec_constraint(2,1);
  pitch_max=spec_constraint(3,1);
  pitch_min=spec_constraint(4,1);
  roll_max=spec_constraint(5,1);
  roll_min=spec_constraint(6,1);
  p_max=spec_constraint(7,1);
  p_min=spec_constraint(8,1);
  q_max=spec_constraint(9,1);
  q_min=spec_constraint(10,1);
  r_max=spec_constraint(11,1);
  r_min=spec_constraint(12,1);
  at_max = spec_constraint(13,1);
  at_min = spec_constraint(14,1);



%% Attitude Casecade NDI start
[set_point_roll_pitch,dot_yaw_set] = generate_roll_pitch_sp(state,set_point,spec_constraint,gain_parameter_attitude,gravity_drag);


[v_sp_sat_fev,pitch_sp_fev,tecs_pitch,gradient_tecs_pitch] = flight_envelope_command_limiting(state,spec_constraint,set_point,set_point_roll_pitch);
% 여기에 fev가 들어가야 함
set_point_roll_pitch(2,1)=pitch_sp_fev;

[dot_sp_roll_pitch] = generate_dot_sp_roll_pitch_yaw(state,set_point_roll_pitch,gravity_drag,gain_parameter_attitude);

at_sp= generate_thrust_sp(state,v_sp_sat_fev,gravity_drag,spec_constraint,gain_parameter_thrust);


dot_sp_roll_pitch_yaw=[dot_sp_roll_pitch;dot_yaw_set];
pqr_sp = generate_pqr_sp(state,dot_sp_roll_pitch_yaw,spec_constraint);

p_sp=pqr_sp(1,1);
q_sp=pqr_sp(2,1);
r_sp=pqr_sp(3,1);

%TECS을 위한 q_cmd 판단 시작


 if (tecs_pitch<-1e-6) && (gradient_tecs_pitch*q_sp<=0)

 else
     q_sp=0;
 end




dot_p_sp=k_p_sp*(p_sp-p);
dot_q_sp=k_q_sp*(q_sp-q);
dot_r_sp=k_r_sp*(r_sp-r);
dot_at_sp=k_at_sp*(at_sp-at);

p_cmd_rar=p + (t_p*dot_p_sp);
q_cmd_rar=q + (t_q*dot_q_sp);
r_cmd_rar=r + (t_r*dot_r_sp);
at_cmd_rar=at+ (t_a*dot_at_sp);

% saturation 시작구문
p_cmd=min(max(p_cmd_rar,p_min),p_max);

q_cmd=min(max(q_cmd_rar,q_min),q_max);




r_cmd=min(max(r_cmd_rar,r_min),r_max);
at_cmd=min(max(at_cmd_rar,at_min),at_max);

control_input=[p_cmd;q_cmd;r_cmd;at_cmd];







    










end

