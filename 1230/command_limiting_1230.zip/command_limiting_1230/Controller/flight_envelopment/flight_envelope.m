function [Roll_nz_at_sat] = flight_envelope(state,backup_state_set_point,spec_constraint ,inner_loop_gain,outer_loop_gain,roll_margin,speed_margin,pitch_margin,gravity_drag )
% 현재 변화된 uav 모델에 맞게 수정해야 함
Roll_nz_at_sat=zeros(3,1);

g=gravity_drag(1,1);
k_acc=gravity_drag(2,1);
n=state(1);
e=state(2);
h=state(3);
roll=state(4);
pitch=state(5);
yaw=state(6);
v=state(7);
p=state(8);
nz=state(9);
at=state(10);

c_p=cos(pitch);
s_p=sin(pitch);
c_y=cos(yaw);
s_y=sin(yaw);
c_r=cos(roll);
s_r=sin(roll);
tan_pitch=tan(pitch);

dot_pitch = (g/v)*(nz*c_r - c_p);

v_max=spec_constraint(1,1);
v_min=spec_constraint(2,1);
pitch_max=spec_constraint(3,1);
pitch_min=spec_constraint(4,1);
roll_max=spec_constraint(5,1);
roll_min=spec_constraint(6,1);
roll_rate_max=spec_constraint(7,1);
roll_rate_min=spec_constraint(8,1);
nz_max=spec_constraint(9,1);
nz_min=spec_constraint(10,1);
at_max=spec_constraint(11,1);
at_min=spec_constraint(12,1);

k_h=outer_loop_gain(1,1);
k_v=outer_loop_gain(2,1);
k_yaw=outer_loop_gain(3,1);
k_pitch=inner_loop_gain(1,1);
k_pitch_damp=inner_loop_gain(2,1);
k_nz=inner_loop_gain(3,1);
k_roll=inner_loop_gain(4,1);
k_P=inner_loop_gain(5,1);
k_t=inner_loop_gain(6,1);


n_sp=backup_state_set_point(1,1);    % 이것은 인풋이 맞음
e_sp=backup_state_set_point(2,1);    % 이것은 인풋이 맞음
h_sp=backup_state_set_point(3,1);    % 이것은 인풋이 맞음
roll_sp=backup_state_set_point(4,1); % 지금 이 부분 수정이 필요함 이게 아마도 아웃풋이 될듯
pitch_sp=backup_state_set_point(5,1);% 이 부분도 수정이 필요함 이게 아마다 아웃풋이 됨
yaw_sp=backup_state_set_point(6,1);  % 이것은 인풋이 맞음 
p_sp=backup_state_set_point(7,1);    % 이것은 지금 인풋인지 아웃풋인지 확인
nz_sp=backup_state_set_point(8,1);   % 이것은 아웃풋이 맞음
v_sp=backup_state_set_point(9,1);    % 이것은 인풋이 맞음

%% 허용 롤각을 제한하는 법
c_p = cos(pitch); s_p = sin(pitch);
c_r = cos(roll);  s_r = sin(roll);
dot_pitch = (g/v)*(nz*c_r - c_p);

error_yaw = atan2(sin(yaw_sp - yaw), cos(yaw_sp - yaw));
turn_accel = (v * (k_yaw * error_yaw)) / g;
roll_sp_rar = atan(turn_accel);
roll_sp_sat = saturation_tanh(roll_sp_rar,roll_max);

%% 피치각 자체를 제약하는 법
   % 여기서 만약에 지금 그냥 현재 고도를 원하는 것이라면은???
    
    pitch_sp_rar = k_h * (h_sp - h) / v;
    pitch_sp_sat = min(max(pitch_sp_rar, pitch_min + pitch_margin), pitch_max - pitch_margin);
    nz_sp_rar = (1/c_r) * (c_p + (v/g)*( k_pitch*(pitch_sp_sat - pitch) - k_pitch_damp*dot_pitch ));
    
    % 피치각 상한 구현
    
    ratio_max=(pitch-(pitch_max-pitch_margin))/(pitch_max-(pitch_max-pitch_margin));
    nz_safe_pitch_max=cos(pitch_max)/c_r;
    s_max=min(max(ratio_max,0),1);
    nz_sp= min(max(nz_sp_rar, nz_min), nz_max);
    nz_soft_upper=nz_sp-s_max*(nz_sp-nz_safe_pitch_max);
    
    pitch_soft_min = pitch_min + pitch_margin;  % 하한에서 margin만큼 위쪽이 soft 구간
    
    % 피치가 pitch_soft_min에서 pitch_min으로 내려갈수록 0 -> 1로 증가
    ratio_min = (pitch - pitch_soft_min) / (pitch_min - pitch_soft_min);
    s_min     = min(max(ratio_min, 0), 1);      % 0 ~ 1로 클램프
    
    % 피치가 pitch_min일 때의 Nz 하한 (더 숙이지 않게 만드는 안전 Nz)
    nz_safe_pitch_min = cos(pitch_min) / c_r;
    
    % 기본 Nz 명령은 이미 위에서 saturation 된 nz_sp_sat 사용
    % s_min = 0  → nz_soft_lower = nz_sp_sat
    % s_min = 1  → nz_soft_lower = nz_safe_pitch_min
    nz_soft_lower = nz_sp - s_min * (nz_sp - nz_safe_pitch_min);
    
   
%% 실속 속도 보호를 위한 지금 일단 가장 간단한 버전(나중에 tecs으로 아예 바꾸어야 함)
 % k_stall=1.5;
 % nz_upper_stall=(v/(k_stall*v_min))^2;
 % nz_max_stall_pitch_protect=min(nz_soft_upper,nz_upper_stall);


    nz_cmd = min(nz_sp, nz_soft_upper); % 상한 잘라내기 
    
    % 하한 쪽에서도 올려줌
    nz_cmd = max(nz_cmd, nz_soft_lower);
    
    % 전역 nz_min / nz_max 보정
    nz_sp_sat = min(max(nz_cmd, nz_min), nz_max);
    
    % Hartmann, Gary L., James A. Hauge, and Russell C. Hendrick. F-8C digital CCV flight control laws. No. NASA-CR-2629. 1976.
    % 지금 일단 피치각만 보호를 하는 로직은 해당 논문의 16page.(pdf 프로그램 기준으로는 31page임)
    
    
    
    %% 속도를 제약하는 법

    nz_eff   = max(1.0, min(nz, nz_max));                 % nz 보호
    v_floor  = v_min * sqrt(nz_eff);                      % stall 증가 반영
    v_floor  = min(v_floor, v_max - speed_margin);        % 하한이 상한 넘지 않게
    
    v_sp_sat = min(max(v_sp, v_floor + speed_margin), ...
                   v_max - speed_margin);

    % 원하는 추력 모델 생성 시작

      accleration_setpoint = k_v * (v_sp_sat - v) ;
      at_setpoint=accleration_setpoint + g*s_p + k_acc*(v^2)  ;
      at_setpoint_sat=min(max(at_setpoint,at_min),at_max) ;
      at_sp_sat=k_t*(at_setpoint_sat-at) ;

      % at_cmd_rar=t_v*at_sp_sat+at;
      % at_sp_sat=min(max(at_cmd_rar,at_min),at_max) ;

   Roll_nz_at_sat=[roll_sp_sat;nz_sp_sat;at_sp_sat];



end

