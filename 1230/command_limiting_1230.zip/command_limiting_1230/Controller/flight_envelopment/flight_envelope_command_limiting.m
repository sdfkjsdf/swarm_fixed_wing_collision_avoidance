function [v_sp_sat,pitch_sp_fev,tecs_pitch,gradient_tecs_pitch] = flight_envelope_command_limiting(state,spec_constraint,set_point,set_point_roll_pitch)

%% state get

    n=state(1);
    e=state(2);
    d=state(3);
    roll=state(4);
    pitch=state(5);
    yaw=state(6);
    v=state(7);
    p=state(8);
    q=state(9);
    r=state(10);
    at=state(11);

%% spec_constraint set

  v_max=spec_constraint(1,1);
  v_min=spec_constraint(2,1);
  pitch_max=spec_constraint(3,1);
  pitch_min=spec_constraint(4,1);
  roll_max=spec_constraint(5,1);
  roll_min=spec_constraint(6,1);
  p_max=spec_constraint(7,1);
  p_min=spec_constraint(8,1);
  q_max=spec_constraint(9,1);
  q_min=spec_constraint(10,1);
  r_max=spec_constraint(11,1);
  r_min=spec_constraint(12,1);
  at_max = spec_constraint(13,1);
  at_min = spec_constraint(14,1);

%% 각변환
    c_p=cos(pitch);
    s_p=sin(pitch);
    divide_c_p=1/c_p;
    c_y=cos(yaw);
    s_y=sin(yaw);
    c_r=cos(roll);
    s_r=sin(roll);
    tan_pitch=tan(pitch);
%% setpoint get

v_sp = set_point(7,1) ; 
roll_sp=set_point_roll_pitch(1,1);
pitch_sp=set_point_roll_pitch(2,1);


%% spec 제약조건  get

  v_max=spec_constraint(1,1);
  v_min=spec_constraint(2,1);
  pitch_max=spec_constraint(3,1);
  pitch_min=spec_constraint(4,1);
  roll_max=spec_constraint(5,1);
  roll_min=spec_constraint(6,1);
  p_max=spec_constraint(7,1);
  p_min=spec_constraint(8,1);
  q_max=spec_constraint(9,1);
  q_min=spec_constraint(10,1);
  r_max=spec_constraint(11,1);
  r_min=spec_constraint(12,1);
  at_max = spec_constraint(13,1);
  at_min = spec_constraint(14,1);


%% v_stall 연산
roll_fff=(max(abs(roll_sp),abs(roll)));
stall_gain=1/cos(roll_fff);
v_stall=v_min*sqrt(stall_gain);
v_lowwer=max(v_stall,v_min);
v_sp_sat=min(max(v_sp,v_lowwer),v_max);


%% flight envelope start
c1=0.1;
c2=0.8;

pitch_upper=pitch_max*tanh(c1+(v-v_lowwer)/c2);
pitch_lowwer=pitch_min*tanh(c1+(v_max-v)/c2);

pitch_sp_fev=min(max(pitch_sp,pitch_lowwer),pitch_upper);


tecs_pitch=(pitch-(pitch_upper+pitch_lowwer)/2)^2-(pitch_upper-(pitch_upper+pitch_lowwer)/2)^2;
gradient_tecs_pitch=2*(pitch-(pitch_upper+pitch_lowwer)/2);


end

