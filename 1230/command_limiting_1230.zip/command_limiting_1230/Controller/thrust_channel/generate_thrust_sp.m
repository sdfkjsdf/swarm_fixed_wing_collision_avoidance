function [at_sp] = generate_thrust_sp(state,v_sp_sat_fev,gravity_drag,spec_constraint,gain_parameter_thrust)
at_sp=0;


%% state get 

    n=state(1);
    e=state(2);
    d=state(3);
    roll=state(4);
    pitch=state(5);
    yaw=state(6);
    v=state(7);
    p=state(8);
    q=state(9);
    r=state(10);
    at=state(11);

%% 각도 변환
    c_p=cos(pitch);
    s_p=sin(pitch);
    divide_c_p=1/c_p;
    c_y=cos(yaw);
    s_y=sin(yaw);
    c_r=cos(roll);
    s_r=sin(roll);
    tan_pitch=tan(pitch);


%% 중력 및 항력 설정

  g=gravity_drag(1,1);
  k_acc = gravity_drag(2,1);


%% setpoint 설정 
    
    v_set = v_sp_sat_fev ; 



%% spec_constraint
  v_max=spec_constraint(1,1);
  v_min=spec_constraint(2,1);
  pitch_max=spec_constraint(3,1);
  pitch_min=spec_constraint(4,1);
  roll_max=spec_constraint(5,1);
  roll_min=spec_constraint(6,1);
  p_max=spec_constraint(7,1);
  p_min=spec_constraint(8,1);
  q_max=spec_constraint(9,1);
  q_min=spec_constraint(10,1);
  r_max=spec_constraint(11,1);
  r_min=spec_constraint(12,1);
  at_max = spec_constraint(13,1);
  at_min = spec_constraint(14,1);

%% 파라미터 get set

k_v=gain_parameter_thrust;

%% V_stall  설정





%% main start

v_sp_sat=min(max(v_set,v_min),v_max);

error_v=v_sp_sat-v;

dot_error_v=k_v*(error_v);

at_sp_rar=dot_error_v+(g*s_p)+(k_acc*(v^2));

at_sp=min(max(at_sp_rar,at_min),at_max);



end

