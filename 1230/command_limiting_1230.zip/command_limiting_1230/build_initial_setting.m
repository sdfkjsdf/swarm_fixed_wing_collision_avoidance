%%% Small_fixed_wing 관련 모델
%현재 버전은 지금  "Investigation of Practical Flight Envelope Protection Systemsfor Small Aircraft
% 해당 논문을 기준으로 flight envelope가 잘 되는지 안되는지를 판단하기 위한 내용이다
% 지금 해당 코드는 소형 고정익 무인기를 기준으로 설계가 되는 내용임
% 중대형 고정익 무인기와의 가장 큰 차이점은 현재 추력에 대한 시간지연은 고려하게 됨


%% fixed wing uav 모델링 관련 내용
% 지금 x의 차원은 총 11차원 
% 제어입력 u의 차원은 총 4차원
% x= [n, e, d, roll, pitch, yaw, speed, p, q, r];
% 참고로 지금 좌표계는 NED 좌표계임

% 중력 계수 및 항력 계수 관련 내용
    % g=gravity_drag(1,1);
    % k_acc=gravity_drag(2,1);

%% 상태 차원 선언 관련 내용
    % n=state(1);
    % e=state(2);
    % d=state(3);
    % roll=state(4);
    % pitch=state(5);
    % yaw=state(6);
    % v=state(7);
    % p=state(8);
    % q=state(9);
    % r=state(10);
    % at=state(11);


%% 각 변환에 자주 쓰는 내용 선언 
    % c_p=cos(pitch);
    % s_p=sin(pitch);
    % divide_c_p=1/c_p;
    % c_y=cos(yaw);
    % s_y=sin(yaw);
    % c_r=cos(roll);
    % s_r=sin(roll);
    % tan_pitch=tan(pitch);

%% 시간지연 상수에 대한 내용
  % t_p : p에 대한 시간 지연을 의미
  % t_q : q에 대한 시간 지연을 의미
  % t_r : r에 대한 시간 지연을 의미
  % t_a : at에 대한 시간 지연을 의미


%% fixed wing uav model 관련 내용
% dfx/dt =d[n =  v * c_p * c_y
%           e =  v * c_p * s_y
%           d = -v * s_p       
%           roll = p + (q*s_r*tan_pitch)+(r*c_r*tan_pitch)
%           pitch = (q*c_r)-(r*s_r)
%           yaw = ((q*s_r)+(r*c_r))/c_p
%           speed = -g * s_p + at - k_acc* v^2 ,  Drag_force=k_acc* v^2
%           p =  (-1 / t_p) * p
%           q =  (-1 / t_q) * q
%           r =  (-1 / t_r) * r
%           at = (-1 / t_a) * at ] % at=T/m



% gx = sym(zeros(11, 4));
% gx(8, 1) = 1 / t_p  ;
% gx(9, 2) = 1 / t_q  ;
% gx(10, 3) = 1 / t_r ;
% gx(11,4)  = 1 / t_a ;

% u=zeros(4,1)
    % u=[ p_cmd ;
    %     q_cmd ; 
    %     r_cmd ; 
    %     at_cmd ]
    


%% 기체 spec 선언

  % 기체의 비행영역보호 및 boxed control input 선언
    g=9.81 ;

  % 기체의 항력계수 선언
    density= 1.1 ; % 지금 여기서 5000~6000m 기준임
    c_d=0.03;
    s=1.5;   % 기체의 총 날개 면적을 의미
    m=20; % 기체의 질량을 의미
    k_acc= 0.5*density*c_d*s/m;        % Drag_gain

   


%% 시상수 정의
    t_p= 0.5 ; % 2.0~5.0 % 이제는 지금 그냥 추력 시상수로 대체가 됨
    t_q= 0.6 ; % 0.5~0.8
    t_r = 0.8 ; %0.5~1.0 
    t_a = 1.0 ; %1.0~2.0

%% 기체의 물리적인 한계 설정
    v_max= 40 ;  % m/s
    v_min= 18   ; % m/s
    pitch_max=deg2rad(25);
    pitch_min=deg2rad(-10);
    roll_max=deg2rad(40);
    roll_min=-deg2rad(40);
%% Boxed control input 설정

    p_max=deg2rad(45); 
    p_min=-deg2rad(45);

    q_max=deg2rad(30);
    q_min=-deg2rad(30);

    r_max=deg2rad(15);
    r_min=-deg2rad(15);


    at_max=5; % 5~10  
    at_min=0; %
        % 지금 여기서 해석에 있어서 주의해야 할 부분이
        % 우리가 추력이 T 이라고 할 때, 편의상 at=T/m 으로 표현
        % 왜냐하면 이렇게 표현을 해주어야 지금 나중에 soft 함수로 saturation시 오버플로우가 안남
        
%% Margin 설정
    roll_margin=deg2rad(3);
    pitch_margin=deg2rad(3);
    speed_margin=2;

   
%% 파라미터 통합
  gravity_drag=[g;k_acc];
  spec_constraint=[v_max;v_min;pitch_max;pitch_min;roll_max;roll_min;p_max;p_min;q_max;q_min;r_max;r_min;at_max;at_min];
  % spec_constraint의 차원은 14차원
  time_constant=[t_p;t_q;t_r;t_a];
  % time_constant의 차원은 4차원
  %% 현재 내부 루프 문에서 파라미터를 사용 시 다음과 같이 됨

  % g=gravity_drag(1,1);
  % k_acc = gravity_drag(2,1);

  % v_max=spec_constraint(1,1);
  % v_min=spec_constraint(2,1);
  % pitch_max=spec_constraint(3,1);
  % pitch_min=spec_constraint(4,1);
  % roll_max=spec_constraint(5,1);
  % roll_min=spec_constraint(6,1);
  % p_max=spec_constraint(7,1);
  % p_min=spec_constraint(8,1);
  % q_max=spec_constraint(9,1);
  % q_min=spec_constraint(10,1);
  % r_max=spec_constraint(11,1);
  % r_min=spec_constraint(12,1);
  % at_max = spec_constraint(13,1);
  % at_min = spec_constraint(14,1);

  % t_p=time_constant(1,1);
  % t_q=time_constant(2,1);
  % t_r=time_constant(3,1);
  % t_a=time_constant(4,1);

 


%% GAIN 정의

    k_yaw=0.4;   % 해당 gain은 yaw_error을 통해서 d(yaw_error)/dt을 구함
    k_roll=2.5;  % 해당 gain 은 dot_roll_sp=k_roll*(roll_sp-roll); 을 만들 때 사용
    k_d=0.3; % 해당 gain은 error_d=d_set-d; dot_error_d=k_d*(error_d); 을 만들 떄 사용
    k_pitch=2.5; % 해당 gain은  dot_pitch_sp=k_pitch*(pitch_sp-pitch);을 만들 떄 사용

  
    gain_parameter_attitude=[k_yaw;k_roll;k_d;k_pitch];


    k_v=0.5;
    gain_parameter_thrust=k_v;
    
    % k_yaw=gain_parameter(1,1);   % 해당 gain은 yaw_error을 통해서 d(yaw_error)/dt을 구함
    % k_roll=gain_parameter(2,1);  % 해당 gain 은 dot_roll_sp=k_roll*(roll_sp-roll); 을 만들 때 사용
    % k_d=gain_parameter(3,1);     % 해당 gain은 error_d=d_set-d; dot_error_d=k_d*(error_d); 을 만들 떄 사용
    % k_pitch=gain_parameter(4,1); % 해당 gain은  dot_pitch_sp=k_pitch*(pitch_sp-pitch);을 만들 떄 사용

    ndi_parameter=zeros(4,1);

    k_p_sp=5;
    k_q_sp=4.0;
    k_r_sp=2.5;
    k_at_sp=1.5;

    ndi_parameter=[k_p_sp;k_q_sp;k_r_sp;k_at_sp];









%% 각 파라미터가 어떻게 CASCADE NDI으로 변환이 되는 지에 대한 예시 코드


    % 롤각을 만드는 법

        % dot_pitch = (g/v)*(nz*c_r - c_p);
        % error_yaw = atan2(sin(yaw_sp - yaw), cos(yaw_sp - yaw));
        % turn_accel = (v * (k_yaw * error_yaw)) / g;
        % roll_sp_rar = atan(turn_accel);
        % roll_sp_sat = saturation_tanh(roll_sp_rar,roll_max);

    %  Nz setpoint을 만드는 법
        %  pitch_sp_rar = k_h * (h_sp - h) / v;
        %  pitch_sp_sat = min(max(pitch_sp_rar, pitch_min + pitch_margin), pitch_max - pitch_margin);
        %  nz_sp_rar = (1/c_r) * (c_p + (v/g)*( k_pitch*(pitch_sp_sat - pitch) - k_pitch_damp*dot_pitch ));

    % at_cmd을 만드는 법
      % accleration_setpoint = k_v * (v_sp_sat - v)
      % at_setpoint=accleration_setpoint + g*s_p + k_acc*v^2  여기서 한번
      % at_setpoint_sat=min(max(at_setpoint,at_min),at_max) ;
      % dot_at_sepoint=k_t*(at_setpoint_sat-at) ;
      % at_cmd_rar=t_v*dot_at_sepoint+at;
      % at_sp_sat=min(max(at_cmd_rar,at_min),at_max) ;



%% % [n;e;d;롤각;피치각;요각;속도;p;g;r;at]
  initial_condition=[0;
                     0;
                     0;
                     0;
                     0;
                     0;
                     v_min;
                     0;
                     0;
                     0;
                     at_max/2];

% [n;e;h;롤각;피치각;요각;p,nz,v]
  nominal_state_set_point=[100000000;
                           0;
                           -30000;
                           0;
                           0;
                           0;
                           v_min;
                           0;
                           0;
                           0;
                           0];

% % 백업 컨트롤러에 대한 setpoint 설정
%   backup_state_set_point=[0;
%                           0;
%                           backup_hight;
%                           0;
%                           0;
%                           0;
%                           v_max;
%                           0;
%                           1;
%                           0];
% 
  %% Setpoint에 대한 내용
  % n_set = set_point(1,1) ;
  % e_set = set_point(2,1) ;
  % d_set = set_point(3,1) ;
  % v_set = set_point(7,1) ; 
  












%%

% k_smooth=30; % 나중에 soft min 을 구현할 떄 쓰는 파라미터이기는 함

% k_pitch=inner_loop_gain(1,1);
% k_pitch_damp=inner_loop_gain(2,1);
% k_nz=inner_loop_gain(3,1);
% k_roll=inner_loop_gain(4,1);
% k_P=inner_loop_gain(5,1);
% k_t=inner_loop_gain(6,1);



     





%% 나중에 자코비안 지금 심볼릭 미분한 것을 넣을 때 파라미터 한꺼번에 넣으면 되는 것들 
% %% in3 -> 지금 params을 넣으면 됨
% 
% params = [k_nz, k_roll, k_P, ...
%           r_max, r_min, ...
%           nz_max, nz_min, at_max, at_min, ...
%           t_p, t_z, t_v, g,k_acc, k_smooth];
% %% CBF용 지금 제약조건 설정
% 
%     p_g=[0;0;1000]; % 지금 이거 이상 올라가면 안되는 고도를 의미
%     n_g=-1*p_g/norm(p_g);
% 
% 
%      % hight_constraint
%      backup_hight=950;
%      p_g_c=[0;0;1000]; % 지금 이거 이상 올라가면 안되는 고도를 의미
%      n_g_c=-1*p_g_c/norm(p_g_c);
%      p_g_b=[0;0;backup_hight];
%      n_g_b=-1*p_g_b/norm(p_g_b);


%% 초기조건 정의
% state=[n
%        e
%        h
%        roll
%        pitch,
%        yaw,
%        v(=speed),
%        p(=roll rate),
%        nz,
%        at(=T/m) ]^T


