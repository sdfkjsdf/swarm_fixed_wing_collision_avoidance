function gamma_out = build_gamma( ...
    current_x, current_qp, current_qb, ...  % 초기값 (t 시점)
    backup_state_set_point, outer_loop_gain, inner_loop_gain, ... % 파라미터들
    g, spec_constraint, roll_margin,pitch_margin, speed_margin, time_constant, ...
     k_smooth,p_g_c,n_g_c,p_g_b,n_g_b,gravity_drag)

    % 1. 예측 설정
    T_horizon = 10;       % 예측 시간 (예: 1초)
    N_steps = 100;          % 스텝 수 (분해능)
    dt = T_horizon / N_steps; % 델타 타우 (d_tau)
    
    % 2. 초기 상태 벡터 합치기 (30x1)
    % [phi_b; qp; qb]
    augmented_state = [current_x; current_qp; current_qb];

    % current_x     : x
    % current_qp    : qp(0,x)=fp(x)
    % current_qb    : qb(0,x)=fcl(x)

    
    % cbf을 정의 
    class_k1=0.3;
    class_k2=0.5;

    grad_h_x_c_altitude = zeros(10, 1);
    grad_h_x_c_altitude(1:3, 1) = n_g_c;  % 9*1이 나옴 
    grad_h_x_b_altitude = zeros(10, 1);
    grad_h_x_b_altitude(1:3, 1) = n_g_b;  % 9*1이 나옴 






    % 3. 궤적 저장용 변수 (선택 사항)
    trajectory_history = zeros(30, N_steps+1);

    a_total=zeros(1, N_steps+3);
    b_total=zeros(1, N_steps+3);

    
    trajectory_history(:,1) = augmented_state;
    a=zeros(1, N_steps+1);
    b=zeros(1, N_steps+1);

    tau_position=augmented_state(1:3,:);
   [h_comp, grad_h_comp, h_b_altitude, grad_b_alt] = cbf_part(n_g_c,n_g_b,p_g_c,p_g_b,spec_constraint,augmented_state,pitch_margin,speed_margin);
    a(1,1)=  grad_h_comp'*augmented_state(11:20,:) + class_k1*(h_comp );
    b(1,1)=  grad_h_comp'*augmented_state(21:30,:) - grad_h_comp'*augmented_state(11:20,:) ;
    





    
    a_final=0;

    b_final=0;













    
    % 4. RK4 적분 루프 (이 부분이 핵심입니다!)
    % Simulink의 한 스텝 안에서 루프가 다 돌아갑니다.
    for i = 1:N_steps
        
        % 현재 상태
        y = augmented_state;
        
        % RK4 Step 1
        k1 = propagation_backup_directional(backup_state_set_point, y(1:10), y(11:20), y(21:30), ...
             outer_loop_gain, inner_loop_gain, g, spec_constraint, ...
             roll_margin,pitch_margin, speed_margin, time_constant,  k_smooth,gravity_drag);
             
        % RK4 Step 2
        y2 = y + 0.5 * dt * k1;
        k2 = propagation_backup_directional(backup_state_set_point, y2(1:10), y2(11:20), y2(21:30), ...
             outer_loop_gain, inner_loop_gain, g, spec_constraint, ...
             roll_margin,pitch_margin, speed_margin, time_constant,  k_smooth,gravity_drag);
             
        % RK4 Step 3
        y3 = y + 0.5 * dt * k2;
        k3 = propagation_backup_directional(backup_state_set_point, y3(1:10), y3(11:20), y3(21:30), ...
             outer_loop_gain, inner_loop_gain, g, spec_constraint, ...
             roll_margin,pitch_margin, speed_margin, time_constant,  k_smooth,gravity_drag);
             
        % RK4 Step 4
        y4 = y + dt * k3;
        k4 = propagation_backup_directional(backup_state_set_point, y4(1:10), y4(11:20), y4(21:30), ...
             outer_loop_gain, inner_loop_gain, g, spec_constraint, ...
             roll_margin,pitch_margin, speed_margin, time_constant, k_smooth,gravity_drag);
             
        % 상태 업데이트 (Integration)
        augmented_state = y + (dt / 6.0) * (k1 + 2*k2 + 2*k3 + k4);
        
        % 저장
        trajectory_history(:, i+1) = augmented_state;
        [h_comp, grad_h_comp, h_b_altitude, grad_b_alt] = cbf_part(n_g_c,n_g_b,p_g_c,p_g_b,spec_constraint,augmented_state,pitch_margin,speed_margin);
        a(1,i+1)=  grad_h_comp'*augmented_state(11:20,:) + class_k1*(h_comp );
        b(1,i+1)=  grad_h_comp'*augmented_state(21:30,:) - grad_h_comp'*augmented_state(11:20,:) ;
    

    end
    
    final_state = augmented_state;
    [h_comp, grad_h_comp, h_b_altitude, grad_b_alt] = cbf_part(n_g_c,n_g_b,p_g_c,p_g_b,spec_constraint,augmented_state,pitch_margin,speed_margin);
        a(1,i+1)=  grad_h_comp'*augmented_state(11:20,:) + class_k1*(h_comp );
        b(1,i+1)=  grad_h_comp'*augmented_state(21:30,:) - grad_h_comp'*augmented_state(11:20,:) ;
    
    a_final=grad_b_alt'*final_state(11:20,:) + class_k2*( h_b_altitude );
    b_final=grad_b_alt'*augmented_state(21:30,:) - grad_b_alt'*augmented_state(11:20,:) ;
    if n_g_b'*(  final_state(1:3,1)-p_g_b)<-1
        disp("Terminal state coudn't reach terminal set")
        disp( n_g_b'*(  final_state(1:3,1)-p_g_b))


    end


    a_total=[a,a_final,0,1];
    b_total=[b,b_final,1,-1];

    valid_idx = b_total > 1e-3 ; % 0으로 나누기 방지 및 양수 필터링
    
    if any(valid_idx)
        % 2. 유효한 것들만 나눗셈
        candidates = -a_total(valid_idx) ./ b_total(valid_idx);
        
        % 3. 그 중 최댓값 선택 (가장 빡빡한 하한선)
        gamma = max(candidates);
        gamma = min(max(gamma, 0), 1.0);
        
        % (옵션) 이론상 gamma는 1을 넘을 수 없으므로 클리핑
       
    else
        gamma=0;
       
    end
    
    % 최종 출력
    gamma_out = gamma;








end