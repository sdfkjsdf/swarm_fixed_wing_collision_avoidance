function [h_comp, grad_h_comp, h_b_altitude, grad_b_alt] = cbf_part(n_g_c,n_g_b,p_g_c,p_g_b,spec_constraint,augmented_state,pitch_margin,speed_margin)
% 현재 변화된 uav 모델에 맞게 수정해야 함
% 지금 이 값도 결국에는 v_min,v_max을 바꾸어 주어야 함....
% 왜냐하면은 지금 실속속도는 하중배수에 대해서 달라지기 때문임

    % n=state(1);
    % e=state(2);
    % h=state(3);
    % roll=state(4);
    % pitch=state(5);
    % yaw=state(6);
    % v=state(7);
    % p=state(8);
    % nz=state(9);
    % at=state(10);


v_max     = spec_constraint(1,1);
v_min     = spec_constraint(2,1);
pitch_max = spec_constraint(3,1);
pitch_min = spec_constraint(4,1);

% -------------------------
% 1) raw constraint hbar_i 계산
% -------------------------
hbar_c_altitude = n_g_c'*(augmented_state(1:3,1) - p_g_c);

h_b_altitude = n_g_b'*(augmented_state(1:3,1) - p_g_b);
grad_b_alt   = zeros(10,1); 
grad_b_alt(1:3) = n_g_b;

hbar_v_min  = augmented_state(7,1) - (v_min+speed_margin);        % v >= v_min
hbar_v_max  = (v_max-speed_margin) - augmented_state(7,1);        % v <= v_max

hbar_pitch_min = augmented_state(5,1) - (pitch_min+pitch_margin); % pitch >= pitch_min
hbar_pitch_max = (pitch_max-pitch_margin) - augmented_state(5,1); % pitch <= pitch_max

hbar_list = [hbar_c_altitude;
             hbar_v_min;
             hbar_v_max;
             hbar_pitch_min;
             hbar_pitch_max];

% -------------------------
% 2) raw gradient 준비 (각 열이 grad hbar_i)
% -------------------------
grad_c_alt = zeros(10,1); grad_c_alt(1:3) = n_g_c;

grad_v_min = zeros(10,1); grad_v_min(9) =  1;
grad_v_max = zeros(10,1); grad_v_max(9) = -1;

grad_pitch_min = zeros(10,1); grad_pitch_min(5) =  1;
grad_pitch_max = zeros(10,1); grad_pitch_max(5) = -1;

Gbar = [grad_c_alt, grad_v_min, grad_v_max, grad_pitch_min, grad_pitch_max]; % 9x5

% -------------------------
% 3) Remark 1 스케일링: hi = tanh(hbar_i / s_i)
% -------------------------
% s_i는 "경계 근처에서 의미있는 변화 스케일"로 잡아줘야 함
% (예시값. 너 시스템에 맞게 조정)
% *Section II.A (Operations Between Sets)**에서 AND/OR(교집합/합집합) 설명한 뒤 바로 나오는 Remark 1

s_alt   = 50.0;   % [m]
s_v     =  max(2*speed_margin, 1e-3);     % [m/s]
s_pitch =  max(pitch_margin, 1e-3);     % [rad]

s = [s_alt; s_v; s_v; s_pitch; s_pitch];  % 5x1

x = hbar_list ./ s;            % 5x1
h_list = tanh(x);              % 5x1, 항상 [-1,1]

% 체인룰 계수: d/dhbar tanh(hbar/s) = (1/s)*sech^2(hbar/s)
sech2 = 1 ./ cosh(x).^2;       % sech^2(x)
w = (1 ./ s) .* sech2;          % 5x1

% grad도 같이 스케일: grad_hi = w_i * grad_hbar_i
G = Gbar .* (ones(10,1) * w');   % 9x5 (열별 스케일링)

% -------------------------
% 4) (30) smooth-min (overflow-safe log-sum-exp)
% -------------------------
kappa = 30.0; % 지금 이 값을 너무 작게하면은  감마값에 진동이 너무 심해짐

hmin = min(h_list);
z = -kappa * (h_list - hmin);   % z <= 0
ez = exp(z);

S = sum(ez);
S = max(S, realmin);

h_comp = hmin - (1/kappa) * log(S);

% 디버그 출력(벡터 비교는 any로!)
% if any(h_list < -1e-3)
%     disp("h_list<0 entries:");
%     disp(h_list(h_list<0));
% end

lambda = ez / S;                % 5x1
grad_h_comp = G * lambda;       % 9x1

end
