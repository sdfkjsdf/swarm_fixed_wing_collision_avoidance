function [dx_dt] = propagation_backup_directional(backup_state_set_point,backup_trajectoty_point,qp,qb,outer_loop_gain,inner_loop_gain, g ,spec_constraint,...
    roll_margin,pitch_margin,speed_margin,time_constant,...
    k_smooth,gravity_drag)
% 여기서 set point는 말 그대로 상태 9개에 대한 내용이고
% 지금  backup_controller_set_point 은 롤각 nz,at에 대한 내용임
% 현재 변화된 uav 모델에 맞게 수정해야 함
  g=gravity_drag(1,1);
  k_acc=gravity_drag(2,1);



  dx_dt=zeros(30,1);
  v_max=spec_constraint(1,1);
  v_min=spec_constraint(2,1);
  pitch_max=spec_constraint(3,1);
  pitch_min=spec_constraint(4,1);
  roll_max=spec_constraint(5,1);
  roll_min=spec_constraint(6,1);
  roll_rate_max=spec_constraint(7,1);
  roll_rate_min=spec_constraint(8,1);
  nz_max=spec_constraint(9,1);
  nz_min=spec_constraint(10,1);
  at_max=spec_constraint(11,1);
  at_min=spec_constraint(12,1);

  t_yaw=time_constant(1,1);
  t_p=time_constant(2,1);
  t_z=time_constant(3,1);
  t_v=time_constant(4,1);

    
    k_h=outer_loop_gain(1,1);
    k_v=outer_loop_gain(2,1);
    k_yaw=outer_loop_gain(3,1);
    k_pitch=inner_loop_gain(1,1);
    k_pitch_damp=inner_loop_gain(2,1);
    k_nz=inner_loop_gain(3,1);
    k_roll=inner_loop_gain(4,1);
    k_P=inner_loop_gain(5,1);
    k_t=inner_loop_gain(6,1);


dx_dt=zeros(30,1); 
                   % dx_dt[1:9,1]= ϕb(τ,x) , ϕb(0,x) = x 
                   % dx_dt[10:18,1]=  qp(τ,x), qp(0,x)=fp(x)
                   % dx_dt[19:27,1]=  qb(τ,x), qb(0,x)=fcl(x)

params = [k_nz, k_roll, k_P, ...
          roll_rate_max, roll_rate_min, ...
          nz_max, nz_min, at_max, at_min, ...
          t_p, t_z, t_v, g,k_acc, k_smooth];

backup_controller_input=zeros(3,1);
partial_tau_trajectory_backup=zeros(10,1);
partial_tau_qp=zeros(10,1);
partial_tau_qb=zeros(10,1);

% backup_controller(state,backup_state_set_point,time_constant,spec_constraint ,inner_loop_gain,outer_loop_gain,k_smooth,roll_margin,speed_margin,pitch_margin,gravity_drag)
[backup_controller_input,Roll_nz_at_sat]=backup_controller(backup_trajectoty_point,backup_state_set_point,time_constant,spec_constraint ,inner_loop_gain,outer_loop_gain,k_smooth,roll_margin,speed_margin,pitch_margin,gravity_drag);
partial_tau_trajectory_backup=build_fcl(backup_trajectoty_point,time_constant, gravity_drag, backup_controller_input); % ∂τϕb(τ,x) = fcl(ϕb(τ,x))
Fcl_jaccobian=propagation_fcl_jacobian(backup_trajectoty_point,Roll_nz_at_sat',params); % Fcl(ϕb(τ,x))
partial_tau_qp=Fcl_jaccobian*qp;  % ∂τ qp(τ,x)=Fcl(ϕb(τ,x))qp(τ,x), qp(0,x)=fp(x)
partial_tau_qb=Fcl_jaccobian*qb;  % ∂τ qb(τ,x)=Fcl(ϕb(τ,x))qb(τ,x), qb(0,x)=fcl(x)
dx_dt=[partial_tau_trajectory_backup;partial_tau_qp;partial_tau_qb];



end

