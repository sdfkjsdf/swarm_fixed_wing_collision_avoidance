% 1224/12:30 기준으로 추력모델 변동에 따른 자코비안 행렬 생성 문장 완료하였음
% 여기서의 핵심은 지금 어차피 애매한 값을 쓰면은 그냥 오버플로우 남으로 백업 v_sp 같은 경우 그냥 애초에 초과값을 안주면 됨
%% 1. 심볼릭 변수 선언
% ---------------------------------------------------------
% [in1] state (9x1)
% x=[n,e,h,roll,pitch,yaw,v(=speed),p(=roll rate),nz,at(=T/m) 
syms n e h roll pitch yaw v p nz at  real
state = [n; e; h; roll; pitch; yaw; v ; p; nz; at];

% [in2] setpoints (9x1)
syms roll_sp_sat nz_sp_sat at_sp_sat real
set_points = [roll_sp_sat,nz_sp_sat,at_sp_sat];

% [in3] Parameters
% Gains
syms k_nz k_roll k_P real
% Specs
syms roll_rate_max roll_rate_min real
syms nz_max nz_min at_max at_min real
% Margins & Constants
syms t_p t_z t_v g k_acc real
% Smoothing Parameter
syms k_smooth real

params = [k_nz, k_roll, k_P, ...
          roll_rate_max, roll_rate_min, ...
          nz_max, nz_min, at_max, at_min, ...
          t_p, t_z, t_v, g,k_acc, k_smooth];

%% 2. Parameterized Soft Functions Definition
% ---------------------------------------------------------
% 모든 Soft 함수가 k 값을 인자로 받습니다.
c_p = cos(pitch); s_p = sin(pitch);
c_y = cos(yaw);   s_y = sin(yaw);
c_r = cos(roll);  s_r = sin(roll);
tan_p = tan(pitch);




%% 3. Backup Controller Logic (with Custom k_smooth)
% ---------------------------------------------------------


% [Setting] Scale Factors for k_smooth
% 각도 등 작은 값에는 k_smooth (예: 30) 그대로 사용
% 속도, 고도 등 큰 값에는 scaling factor를 곱해서 k를 작게 만듦
k_normal = k_smooth;



% [5] Final Inputs
u1_before = p + t_p * ( k_roll*(roll_sp_sat - roll) - k_P * p );
u2_before = nz + t_z * ( k_nz * (nz_sp_sat - nz) );
u3_before = t_v*at_sp_sat+at ;

% [6] Final Saturation (GitHub Logic)
% u3 (Thrust)는 오버플로우 위험이 있을 수 있으므로 상황 봐서 k 조절
u1_final = subs_sym_sat(u1_before, roll_rate_max, k_normal);
u2_final = subs_asym_sat(u2_before, nz_min, nz_max, 1*k_normal);
u3_final = subs_asym_sat(u3_before, at_min, at_max, 1*k_normal); 

u_vec = [u1_final; u2_final; u3_final];


%% 4. Dynamics & Jacobian
% ---------------------------------------------------------

fx = [
    v * c_p * c_y;
    v * c_p * s_y;
    v * s_p;
    p + ((nz * g) / v) * s_r * tan_p;
    (g / v) * (nz * c_r - c_p);
    (nz * g * s_r) / (v * c_p);
    -g * s_p + at - k_acc* v^2;
    (-1 / t_p) * p;
    (-1 / t_z) * nz;
    (-1 / t_v) * at
];
%Drag_force=k_acc* v^2

gx = sym(zeros(10, 3));
gx(8, 1) = 1 / t_p;
gx(9, 2) = 1 / t_z;
gx(10, 3) = 1 / t_v;

dx_cl = fx + gx * u_vec;

fprintf('자코비안 계산 중...\n');
J_sym = jacobian(dx_cl, state);

fprintf('함수 파일 생성 중...\n');
 matlabFunction(J_sym, 'File', 'propagation_fcl_jacobian.m', ...
                'Vars', {state, set_points, params}, 'Optimize', true);

fprintf('완료! propagation_fcl_jacobian.m 생성됨.\n');


