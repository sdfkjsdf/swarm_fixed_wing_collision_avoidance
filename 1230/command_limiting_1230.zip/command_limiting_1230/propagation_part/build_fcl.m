function fcl = build_fcl(state,time_constant, gravity_drag, u)

% 현재 변화된 uav 모델에 맞게 수정해야 함
% 12월 24일 12:33 기준으로 수정완료 

fcl=zeros(10,1);
fx=zeros(10,1);
gx=zeros(10,3);

g=gravity_drag(1,1);
k_acc=gravity_drag(2,1);

 n=state(1);
 e=state(2);
 h=state(3);
 roll=state(4);
 pitch=state(5);
 yaw=state(6);
 v=state(7);
 p=state(8);
 nz=state(9);
 at=state(10);

c_p=cos(pitch);
s_p=sin(pitch);
c_y=cos(yaw);
s_y=sin(yaw);
c_r=cos(roll);
s_r=sin(roll);
tan_p=tan(pitch);

  t_yaw=time_constant(1,1);
  t_p=time_constant(2,1);
  t_z=time_constant(3,1);
  t_v=time_constant(4,1);


fx = [
    v * c_p * c_y;
    v * c_p * s_y;
    v * s_p;
    p + ((nz * g) / v) * s_r * tan_p;
    (g / v) * (nz * c_r - c_p);
    (nz * g * s_r) / (v * c_p);
    -g * s_p + at - k_acc* (v^2);
    (-1 / t_p) * p;
    (-1 / t_z) * nz;
    (-1 / t_v) * at
];

gx(8, 1) = 1 / t_p;
gx(9, 2) = 1 / t_z;
gx(10, 3) = 1 / t_v;


fcl =fx+gx*u;