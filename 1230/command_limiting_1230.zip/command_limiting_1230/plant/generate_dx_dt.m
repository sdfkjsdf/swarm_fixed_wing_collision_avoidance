function [dx_dt] = generate_dx_dt(state,time_constant,gravity_drag,control_input)

dx_dt=zeros(11,1);
fx=zeros(11,1);
gx=zeros(11,4);

%%
    n=state(1);
    e=state(2);
    d=state(3);
    roll=state(4);
    pitch=state(5);
    yaw=state(6);
    v=state(7);
    p=state(8);
    q=state(9);
    r=state(10);
    at=state(11);
%%
    c_p=cos(pitch);
    s_p=sin(pitch);
    divide_c_p=1/c_p;
    c_y=cos(yaw);
    s_y=sin(yaw);
    c_r=cos(roll);
    s_r=sin(roll);
    tan_pitch=tan(pitch);

%%
  t_p=time_constant(1,1);
  t_q=time_constant(2,1);
  t_r=time_constant(3,1);
  t_a=time_constant(4,1);

%%
g=gravity_drag(1,1);
k_acc = gravity_drag(2,1);
%%

fx=[ v * c_p * c_y;
     v * c_p * s_y;
     -v * s_p     ;
     p + (q*s_r*tan_pitch)+(r*c_r*tan_pitch);
     (q*c_r)-(r*s_r);
     ((q*s_r)+(r*c_r))/c_p ;
      -g * s_p + at - (k_acc* (v^2)) ;
     (-1 / t_p) * p;
     (-1 / t_q) * q;
     (-1 / t_r) * r;
     (-1 / t_a) * at];

gx(8, 1) = 1 / t_p  ;
gx(9, 2) = 1 / t_q  ;
gx(10, 3) = 1 / t_r ;
gx(11,4)  = 1 / t_a ;

dx_dt=fx+(gx*control_input);




end

