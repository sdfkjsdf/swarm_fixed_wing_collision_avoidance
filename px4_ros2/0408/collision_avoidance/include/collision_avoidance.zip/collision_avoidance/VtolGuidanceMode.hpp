#pragma once

#include <rclcpp/rclcpp.hpp>
#include <limits>
#include <thread>
#include <atomic>
#include <array>
#include <cmath>
#include <vector>
#include <memory>

/* px4-ros2-interface-lib */
#include <px4_ros2/components/mode.hpp>
#include <px4_ros2/control/setpoint_types/fixedwing/lateral_longitudinal.hpp>
#include <px4_ros2/control/setpoint_types/experimental/trajectory.hpp>
#include <px4_ros2/control/vtol.hpp>
#include <px4_ros2/odometry/global_position.hpp>

/* px4 msgs */
#include <px4_msgs/msg/vehicle_odometry.hpp>
#include <px4_msgs/msg/wind.hpp>
#include <px4_msgs/msg/vtol_vehicle_status.hpp>

/* 상태 모니터링용 (각 노드가 자기 InternalState 를 발행) */
#include <std_msgs/msg/string.hpp>

/* 기존 모듈 유지 */
#include <collision_avoidance/StateType.hpp>
#include <collision_avoidance/FlockingGuidance.hpp>


class VtolGuidanceMode : public px4_ros2::ModeBase
{
public:
    /* vehicle_id, total_agent_num 둘 다 생성자에서 받아야 함:
       - vehicle_id      : ModeBase 의 topic_namespace_prefix ("/px4_N") 결정
       - total_agent_num : 생성자에서 _trans_odom_subs / _vtol_status_subs 를
                           몇 개 만들지 결정 → 생성자에 반드시 필요 */
    VtolGuidanceMode(rclcpp::Node & node, int vehicle_id, int total_agent_num);
    ~VtolGuidanceMode() override;

    /* ────────────────────────────────────────────────────
       InternalState: 단일 Mode 안의 내부 비행 단계
       각 단계의 setpoint 로직은 별도 모듈로 분리:
         - FormationControl → FlockingGuidance 모듈
         - (추가 예정) → LeaderFollowerGuidance 모듈, APF 모듈 등

       전환 방식:
         - TransitionToFw → FwCruise: VTOL state 폴링 (자동)
         - 그 외        : setInternalState() 호출로 외부 트리거 가능
       ──────────────────────────────────────────────────── */
    enum class InternalState {
        TransitionToFw,     /* 멀티콥터 → 고정익 천이 */
        FwCruise,           /* 고정익 순항 (단순 코스/고도/속도 유지) */
        FormationControl,   /* 편대비행 (Flocking 모듈) */
        Loitering,          /* 선회/대기 (현재는 stub, 추후 구현) */
        Done                /* 임무 종료 → Executor 가 RTL 수행 */
    };

    /* 외부에서 내부 단계 변경 (Executor / 디버깅 / 서비스 콜백 등) */
    void setInternalState(InternalState state);

    /* 추가 파라미터 설정 (vehicle_id, total_agent_num 은 생성자에서 받음) */
    void setPropagationTime(float t) { m_propagation_time = t; }

    /* ── 라이브러리가 오버라이드 요구하는 함수들 ── */
    void onActivate() override;
    void onDeactivate() override;

    /* 기존 타이머 콜백(10ms) 역할 대체 - 라이브러리가 자동 호출 */
    void updateSetpoint(float dt_s) override;

private:
    /* ── 내부 단계별 setpoint 송신 함수 (각 단계 = 별도 모듈/로직) ── */
    void runTransitionToFw();
    void sendFwCruiseSetpoint();
    void sendFormationSetpoint(float dt_s);   /* dt 받음 (적분용) */
    void sendLoiteringSetpoint();             /* 선회/대기 (stub) */

    /* ── Formation control 진입 시 V_desired 초기화 ── */
    void initializeVdesiredFromCurrent();

    /* ── 바람 보상 계산 (지면속도 → airspeed 변환) ── */
    float computeRequiredAirspeed(float desired_ground_speed, float course);

    /* ── 멀티스레드에서 돌릴 맴버함수 (기존과 완전히 동일) ── */
    void rt_loop();

    /* 노드 핸들 (서브스크라이버 생성용 - 라이브러리가 ModeBase 에 보관함) */
    rclcpp::Node & _node;

    /* ── 라이브러리 setpoint 타입 ── */
    std::shared_ptr<px4_ros2::FwLateralLongitudinalSetpointType> _fw_setpoint;
    std::shared_ptr<px4_ros2::TrajectorySetpointType>            _mc_trajectory;
    std::shared_ptr<px4_ros2::VTOL>                              _vtol;
    std::shared_ptr<px4_ros2::OdometryGlobalPosition>            _global_position; /* 현재 AMSL 고도 조회 */

    /* ── 바람 서브스크라이버 (신규: 바람 보상용) ── */
    rclcpp::Subscription<px4_msgs::msg::Wind>::SharedPtr _wind_sub;

    /* TransferSameCoordinate 노드로 부터 발행되는 공통의 좌표계 기준으로 표현이 되는
       state를 서브스크라이 하는 맴버 변수 정의 (기존 trans_odom_subs_ 유지) */
    std::vector<rclcpp::Subscription<
        px4_msgs::msg::VehicleOdometry>::SharedPtr> _trans_odom_subs; /* 지금 trans_node에서 주는 값을 일단 받기 위한 것임 */

    /* ── 모든 기체의 VTOL 상태 구독 (Formation 진입 동기화용) ──
       각 기체의 /px4_N/fmu/out/vtol_vehicle_status 를 구독해서
       모두 FW 가 됐을 때만 FormationControl 진입 */
    std::vector<rclcpp::Subscription<
        px4_msgs::msg::VtolVehicleStatus>::SharedPtr> _vtol_status_subs;
    std::array<std::atomic<bool>, kMaxAgents> _agent_in_fw{};   /* atomic: 콜백 thread vs main thread 안전 */

    /* 모든 다른 기체가 (자기 포함) FW 모드에 있는지 확인 */
    bool allAgentsInFw() const;

    /* ── InternalState 모니터링 publisher (1Hz) ── */
    rclcpp::Publisher<std_msgs::msg::String>::SharedPtr _state_pub;
    rclcpp::TimerBase::SharedPtr                        _state_pub_timer;
    void publishInternalStateMsg();
    static const char * internalStateName(InternalState s);

    /* ── 내부 단계 상태 변수 (신규) ── */
    InternalState _internal_state{InternalState::TransitionToFw};
    rclcpp::Time  _phase_start_time{};

    /* 토픽이름 제작을 위한 맴버 변수 정의 (기존 유지) */
    int   m_vehicle_ID{1};
    int   m_total_agent_num{0};
    float m_propagation_time{0.0f};

    /* ── 바람 추정값 (신규) ── */
    float _wind_n{0.f};
    float _wind_e{0.f};

    /* ── 목표값 (신규)
       _cruise_altitude_amsl: 천이 완료 시점의 현재 AMSL 고도를 캡처해서
                              그대로 순항 고도로 사용 (이륙 → 천이 → 그 고도 유지) */
    float _desired_course{0.f};
    float _cruise_altitude_amsl{NAN};
    float _desired_ground_speed{15.f};

    /* ────────────────────────────────────────────────────
       스레드용 프라이벗 변수 (기존과 완전히 동일)
       ──────────────────────────────────────────────────── */
    std::thread       rt_thread_;          /* 다른 스레드에서 지금 어느 class에서의 맴버 함수를 구현 할 것인지를 정함 */
    std::atomic<bool> rt_running_{false};  /* 지금 main노드가 꺼저있는 경우에 스래드가 할당이 되면 안됨으로 이것을 중지시키기 위한 것임 */

    /* ────────────────────────────────────────────────────
       스레드간 lock-free 을 위한 큐 기반 자료 전달을 위한 변수 (기존과 완전히 동일)
       ──────────────────────────────────────────────────── */
    StateType::InputQueue   m_input_queue{};   /* Total_state_for_Control m_Total_state_for_Control{}; 을 전달할 때 쓸 예정임 */
                                               /* 아직 다른 output queue는 정의를 하지 않은 상태임 */
    StateType::Check_update agent_updated_{};  /* 전체 수신을 완료 했는 지를 확인하기 위한 용도임 */

    /* 자체 프라이빗 변수: control에 필요한 state만을 집어 넣는 것임
       지금 여기서 어차피 5개 초과하는 agent은 다루지 않을 예정이다 */
    std::array<StateType::State_for_Control, kMaxAgents> m_state_for_Control{}; /* 지금 Odomerty 로부터 subscribe 하는 것들 중에서 필요한 것만 받는 내용을 의미 */

    /* ────────────────────────────────────────────────────
       Flocking 가이던스 + V_desired 적분 상태
       - rt_loop 가 가속도 계산 → atomic 에 store
       - main thread 의 sendFormationSetpoint 가 atomic 읽어서 적분 + setpoint 송신
       ──────────────────────────────────────────────────── */

    /* Flocking 모듈 (rt_loop 안에서만 호출) */
    std::unique_ptr<FlockingGuidance> _flocking;

    /* rt_loop → main thread 로 전달되는 가속도 (NED, m/s^2)
       std::atomic<float> 는 lock-free 로 안전하게 공유 가능 */
    std::atomic<float> _latest_aN{0.f};
    std::atomic<float> _latest_aE{0.f};
    std::atomic<float> _latest_aD{0.f};
    std::atomic<bool>  _formation_ready{false};   /* rt_loop 가 첫 결과를 publish 했는지 */

    /* V_desired (NED, m/s) — main thread 의 sendFormationSetpoint 안에서만 사용 */
    float _v_desired_n{0.f};
    float _v_desired_e{0.f};
    float _v_desired_d{0.f};

    /* 안전 한계 (모두 적용 — 사용자 안전 표 기준) */
    static constexpr float kAccelMaxAbs       = 5.0f;   /* 입력 가속도 saturation [m/s^2] */
    static constexpr float kVdesiredMaxNorm   = 25.0f;  /* V_desired 수평 norm 한계 [m/s] */
    static constexpr float kHeightRateMaxAbs  = 5.0f;   /* fixed-wing 최대 climb/descent [m/s] */
    static constexpr float kAirspeedMin       = 12.0f;  /* stall 회피 [m/s] */
    static constexpr float kAirspeedMax       = 25.0f;  /* overspeed 회피 [m/s] */
    static constexpr float kMinGsForCourse    = 1.0f;   /* 이 값보다 느리면 course 발산 → fallback */
    static constexpr float kDtMin             = 0.001f; /* dt clamp 하한 [s] */
    static constexpr float kDtMax             = 0.1f;   /* dt clamp 상한 [s] */
};
