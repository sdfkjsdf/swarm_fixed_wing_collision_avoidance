#pragma once

/*
   FlockingGuidance
   ----------------
   Olfati-Saber 스타일 flocking 가이던스 (NE 평면 2D)
   - alignment    : 이웃의 속도에 맞추는 항
   - cohesion     : 이웃 쪽으로 끌리는 항
   - separation   : 이웃과 너무 가까우면 밀어내는 항

   원본: ~/Documents/fixed_wing_uav_0213/formation_guidance/FlockingGuidance.cpp
   변경: yawrate/ground_acc 변환 제거 → NE 평면 가속도(2D) 그대로 반환
        TsMessage_t 의존성 제거 → 단순 struct 로 입력 받음
*/

#include <Eigen/Core>
#include <vector>


class FlockingGuidance
{
public:
    struct Parameters
    {
        float lambda{1.0f};            /* alignment 게인 */
        float beta{0.5f};              /* alignment 거리 감쇠 지수 */
        float k1{0.5f};                /* cohesion 게인 (속도-위치 내적) */
        float k2{1.0f};                /* separation/cohesion 게인 (위치 오차) */
        float desired_distance{30.f};  /* 이웃과 유지하고 싶은 거리 [m] */
        int   neighbor_count{4};       /* 평균 분모용 (자기 제외 이웃 수) */
    };

    struct AgentState
    {
        float pos_n{0.f};
        float pos_e{0.f};
        float vel_n{0.f};
        float vel_e{0.f};
    };

    explicit FlockingGuidance(const Parameters& params);

    /* NE 평면 가속도 명령 (m/s^2)
       'others' 에는 자기 자신을 포함하지 않음 */
    Eigen::Vector2f computeAcceleration(
        const AgentState & self,
        const std::vector<AgentState> & others) const;

    /* 런타임 파라미터 갱신 (yaml 재로드 등) */
    void setParameters(const Parameters& params) { _params = params; }
    const Parameters & parameters() const { return _params; }

private:
    Parameters _params;
};
